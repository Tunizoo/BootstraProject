function pdf_open(idx) {window.open(document.getElementsByName("curr_directory")[0].value+document.getElementById("th"+idx).getAttribute("filename"));}

function dir_open(idx) {
	document.getElementsByName("curr_directory")[0].value=document.getElementsByName("curr_directory")[0].value+document.getElementById("th"+idx).getAttribute("filename")+"/";
	var arr=document.getElementsByName("thumbnail");
	for(j=arr.length-1;j>=0;j--) arr[j].remove();
	
	var extract_files=files({directory:"."}).get();
	var l=extract_files.length;
	var thumb=Array(l);
	var th_a=Array(l);
	var th_img=Array(l);
    for(i=0;i<l;i++) {
	thumb[i]=document.createElement('div');
	thumb[i].setAttribute('class', 'col-lg-3 col-md-4 col-xs-6 thumb');
	document.getElementsByClassName("container")[0].appendChild(thumb[i]);
	th_a[i]=document.createElement('a');
	th_a[i].setAttribute('class', 'thumbnail');
	th_a[i].setAttribute('filename', extract_files[i].filename);
	th_a[i].setAttribute('filetype', extract_files[i].type);
	th_a[i].setAttribute('href', '#');
	thumb[i].appendChild(th_a[i]);
	th_img[i]=document.createElement('img');
	th_img[i].setAttribute('class', 'img-responsive');
	th_img[i].setAttribute('src', '../pdf_files/icons/'+extract_files[i].iconname);
	th_a[i].appendChild(th_img[i]);
/*	document.getElementsByClassName("col-lg-3 col-md-4 col-xs-6 thumb")[i].
	document.writeln('            <div class="col-lg-3 col-md-4 col-xs-6 thumb" name="thumbnail">');
	document.writeln('                <a class="thumbnail" href="#" filename='+extract_files[i].filename+'  filetype='+extract_files[i].type+'  onclick="file_open('+i+')" id="th'+i+'">');
	document.writeln('                    <img class="img-responsive img-rounded" src=../pdf_files/icons/'+extract_files[i].iconname+' alt="">');
	document.writeln('    		<input type="hidden" name="nb" value='+i+'>');
	document.writeln('			<script name="open_file"> function file_open(idx) {if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="pdf") pdf_open(idx); else if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="dir") dir_open(idx); else alert("not pdf");} </script>');
	document.writeln('                </a>');
	document.writeln('            </div>');
*/    }

}
