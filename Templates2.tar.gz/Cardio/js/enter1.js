function testUser(){
  var name  =loginform.username.value;
  var passwd=loginform.password.value;
  var is_new_user=loginform.check.checked;

  if(!is_new_user) {
    var extract_user=users({username:name});
    var user=extract_user.first();
    if(user.username!=undefined) {
        if(passwd==user.password){
	  loginform.essai.value=0;
	  return user;
	}
        else {
	  alert('invalid password for user '+user.username);
          loginform.password.value="";
	  loginform.essai.value++;
	  return null;
        }
    }
    else {
	alert('No registered user with that name, you have to check "I am a new user" and register');
        loginform.essai.value++;        
	return null;
    }    
  }
  else {
    var extract_user=users({username:name});
    var user=extract_user.first();
    if(user.username!=undefined){
      alert('This username already exists');
      loginform.username.value="";
      loginform.check.checked=false;	
      loginform.essai.value++;  
      return null;
    }
    else if(loginform.newpass==undefined) {alert("newpass");
      var newpass=document.createElement('input');if(loginform.check.checked) {newpass=loginform.password.cloneNode(true);newpass.name='newpass';newpass.placeholder='Retype Password';newpass.value='';loginform.insertBefore(newpass,loginform.childNodes[5]);}
    }	
    else if(loginform.newpass.value!=loginform.password.value){
      alert('Password fields mismatch');
      loginform.password.value="";
      loginform.newpass.value="";
      loginform.check.checked=false;	
      loginform.essai.value++;
      return null;
    }
    else {
      var new_usr={username:loginform.username.value,password:loginform.password.value,role:"visitor"};
      users.insert(new_usr);alert(new_usr.username);
      var data=users().get();	
      var text_data=new Array(data.length);
      for(i=0;i<data.length;i++) {
	text_data[i]="{username:"+data[i].username+",password:"+data[i].password+",role:"+data[i].role+"}\n";
      }
      var file = new File(text_data, "../taffy/db_users.js", {type: "text/plain;charset=utf-8"});
      saveAs(file);
      loginform.essai.value=0;
      return new_user;
    }
  }
}

function enter() {    

var user=testUser();
if (user==null) {   
    if(loginform.essai.value>=3) loginform.submit();
    return;
}

var extract_files=files({directory:""}).get();
loginform.submit();

//if(user.role=="admin") login("localhost","","");
var w = window.open("");

w.document.writeln('<head>');

w.document.writeln('    <meta charset="utf-8">');
w.document.writeln('    <meta http-equiv="X-UA-Compatible" content="IE=edge">');
w.document.writeln('    <meta name="viewport" content="width=device-width, initial-scale=1">');

w.document.writeln('    <!-- Bootstrap Core CSS -->');
w.document.writeln('    <link href="../startbootstrap-thumbnail-gallery-master/css/bootstrap.min.css" rel="stylesheet">');

w.document.writeln('    <!-- Custom CSS -->');
w.document.writeln('    <link href="../startbootstrap-thumbnail-gallery-master/css/thumbnail-gallery.css" rel="stylesheet">');

w.document.writeln('	<script src="../taffy/taffy.js"> </script>');
w.document.writeln('	<script src="../taffy/db_users.js"> </script>');
w.document.writeln('	<script src="../taffy/db_files.js"> </script>');

w.document.writeln('</head>');

w.document.writeln('<body>');

w.document.writeln('  <div class="container" name="the_container">');

w.document.writeln('    <div class="row">');
w.document.writeln('	  <div class="btn-group">');
w.document.writeln('	    <button type="button" class="btn btn-primary">Resize icons</button>');

if(user.role=="admin"){
    w.document.writeln('	  <button type="button" class="btn btn-primary">Delete</button>');
    w.document.writeln('	  <div class="btn-group">');
    w.document.writeln('	    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">');
    w.document.writeln('	    New <span class="caret"></span></button>');
    w.document.writeln('	    <ul class="dropdown-menu" role="menu">');
    w.document.writeln('	      <li><a href="#">File</a></li>');
    w.document.writeln('	      <li><a href="#">Directory</a></li>');
    w.document.writeln('	    </ul>');
} w.document.writeln('	  </div>');
w.document.writeln('      <input type="text" name="curr_directory" value="">');
w.document.writeln('	</div>');

w.document.writeln('            <div class="col-lg-12">');
w.document.writeln('                <h1 class="page-header">Body document Gallery</h1>');
w.document.writeln('            </div>');
/*
w.document.writeln('            <div class="col-lg-3 col-md-4 col-xs-6 thumb" name="thumbnail">');
w.document.writeln('                <a class="thumbnail" href="#" filename=".."  filetype="dir"  onclick="dir_open(0)" id="th'+0+'">');
w.document.writeln('                    <img class="img-responsive img-rounded" src=../pdf_files/icons/parent.jpeg alt="">');
w.document.writeln('			<script name="open_file"> function file_open(idx) {if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="pdf") pdf_open(idx); else if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="dir") dir_open(idx); else alert("not pdf");} </script>');
w.document.writeln('                </a>');
w.document.writeln('            </div>');
*/
for(i=0;i<extract_files.length;i++) {
w.document.writeln('            <div class="col-lg-2 col-md-3 col-xs-4 thumb" name="thumbnail">');
w.document.writeln('                <a class="thumbnail" href="#" filename='+extract_files[i].filename+'  filetype='+extract_files[i].type+'  onclick="file_open('+i+')" id="th'+i+'" name="thumb_a">');
w.document.writeln('                    <img class="img-responsive img-rounded" name= "icon" src=../pdf_files/icons/'+extract_files[i].iconname+' alt="">');
w.document.writeln('    		<input type="hidden" name="nb" value='+i+'>');
w.document.writeln('			<script name="open_file"> function file_open(idx) {var filetype=document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype");if(filetype=="pdf") pdf_open(idx); else if(filetype=="dir") dir_open(idx); else alert("This is not a pdf file");} </script>');
w.document.writeln('                </a>');
w.document.writeln('            </div>');
}
w.document.writeln('  </div>');

//w.document.writeln('        <hr id="hr">');

w.document.writeln('    <!-- jQuery -->');
w.document.writeln('    <script src="../startbootstrap-thumbnail-gallery-master/js/jquery.js"></script>');

w.document.writeln('    <!-- Bootstrap Core JavaScript -->');
w.document.writeln('    <script src="../startbootstrap-thumbnail-gallery-master/js/bootstrap.min.js"></script>');

w.document.writeln('    <!-- Taffy Data Base -->');
w.document.writeln('	<script src="../taffy/taffy.js"> </script>');
w.document.writeln('	<script src="../taffy/db_users.js"> </script>');
w.document.writeln('	<script src="../taffy/db_files.js"> </script>');

w.document.writeln('    <!-- FTP tools -->');
//w.document.writeln('	<script src="ftp.js"> </script>');
w.document.writeln('	<script src="../FileSaver.js-master/FileSaver.js"> </script>');

w. document.writeln('	<script> function pdf_open(idx) {window.open("../pdf_files/"+document.getElementsByName("curr_directory")[0].value+document.getElementById("th"+idx).getAttribute("filename"));} </script>');
w.document.writeln('	<script src="js/file_open3.js"> </script>');

w.document.writeln('</body>');

}
