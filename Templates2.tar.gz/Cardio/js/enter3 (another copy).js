function testUser(){
  var name  =loginform.username.value;
  var passwd=loginform.password.value;
  var is_new_user=loginform.check.checked;

  if(!is_new_user) {
    var extract_user=users({username:name});
    var user=extract_user.first();
    if(user.username!=undefined) {
        if(passwd==user.password){
	  loginform.essai.value=0;
	  return user;
	}
        else {
	  alert('invalid password for user '+user.username);
          loginform.password.value="";
	  loginform.essai.value++;
	  return null;
        }
    }
    else {
	alert('No registered user with that name, you have to check "I am a new user" and register');
        loginform.essai.value++;        
	return null;
    }    
  }
  else {
    var extract_user=users({username:name});
    var user=extract_user.first();
    if(user.username!=undefined){
      alert('This username already exists');
      loginform.username.value="";
      loginform.check.checked=false;	
      loginform.essai.value++;  
      return null;
    }
    else if(loginform.newpass==undefined) {alert("newpass");
      var newpass=document.createElement('input');if(loginform.check.checked) {newpass=loginform.password.cloneNode(true);newpass.name='newpass';newpass.placeholder='Retype Password';newpass.value='';loginform.insertBefore(newpass,loginform.childNodes[5]);}
    }	
    else if(loginform.newpass.value!=loginform.password.value){
      alert('Password fields mismatch');
      loginform.password.value="";
      loginform.newpass.value="";
      loginform.check.checked=false;	
      loginform.essai.value++;
      return null;
    }
    else {
      var new_usr={username:loginform.username.value,password:loginform.password.value,role:"visitor"};
      users.insert(new_usr);
      var data=users().get();	
      var text_data=new Array(data.length);
      for(i=0;i<data.length;i++) {
	text_data[i]="{username:"+data[i].username+",password:"+data[i].password+",role:"+data[i].role+"}\n";
      }
      var file = new File(text_data, "../taffy/db_users.js", {type: "text/plain;charset=utf-8"});
      saveAs(file);
      loginform.essai.value=0;
      return new_user;
    }
  }
}

function enter() {    

var user=testUser();
if (user==null) {   
    if(loginform.essai.value>=3) loginform.submit();
    return;
}

var extract_files=files({directory:""}).get();
loginform.submit();

/*	var RKelement=document.getElementById("RK");
	function dump(obj) {
	    var out = '';
	    for (var i in obj) {
		out += i + ": " + obj[i] + "\n";
	    }

	    return out;
	}
	alert(dump(RKelement));

	function getDeepElt(node,tag) {
	    if(node.getElementsByTagName(tag).length>0) return doc.getElementsByTagName(tag)[0];
	    var elts=node.getElementsByTagName("*") ;
	    if(elts.length==0) return(null);
	    var out=null;
	    for (var i=0;i<elts.length;i++) {
		out = out || getDeepElt(elts[i],tag);
	    }
	    return out;
	}
*/


//  c.connect({host:"ftp.byethost12.com",port:21,user:"b12_18839787",password:"123-bismillah"});

/*
var file_path = app.activeDocument.fullName
var file = new File ("/home/nizar/Templates/node-ftps-master/README.md");
*/
/*if ( !ExternalObject.webaccesslib ) {
ExternalObject.webaccesslib = new ExternalObject('lib:webaccesslib');
}

var ftp = new FtpConnection("ftp://ftp.byethost12.com") ;
ftp.login("b12_18839787", "bismillah_123");
*/
var RKsrc="var JSFtp = require('/usr/local/lib/node_modules/jsftp');";
RKsrc+="var Ftp = new JSFtp({";
RKsrc+="  host: 'bootstrap.unlimitedhostingfree.co.uk',";
RKsrc+="  port: 21,";
RKsrc+="  user: 'u317946054',";
RKsrc+="  pass: 'bismillah_123'";
RKsrc+="});";

var w = window.open("");

w.document.writeln('<head>');

w.document.writeln('    <meta charset="utf-8">');
w.document.writeln('    <meta http-equiv="X-UA-Compatible" content="IE=edge">');
w.document.writeln('    <meta name="viewport" content="width=device-width, initial-scale=1">');

w.document.writeln('    <!-- Bootstrap Core CSS -->');
w.document.writeln('    <link href="../startbootstrap-thumbnail-gallery-master/css/bootstrap.min.css" rel="stylesheet">');

w.document.writeln('    <!-- Custom CSS -->');
w.document.writeln('    <link href="../startbootstrap-thumbnail-gallery-master/css/thumbnail-gallery.css" rel="stylesheet">');

w.document.writeln('	<script src="../taffy/taffy.js"> </script>');
w.document.writeln('	<script src="../taffy/db_users.js"> </script>');
w.document.writeln('	<script src="../taffy/db_files.js"> </script>');
w.document.writeln(RKsrc);
w.document.writeln('<script src="https://embed.runkit.com"></script>');
w.document.writeln('<div id="RK"></div>');
w.document.writeln('<script>');
w.document.writeln('var notebook = RunKit.createNotebook({');
w.document.writeln('    element: document.getElementById("RK"),');
w.document.writeln('    source: \"'+RKsrc+'\"');
w.document.writeln('});');
//w.document.writeln('document.RKnotebook=notebook;');
//w.document.writeln('document.RKnotebook.evaluate(alert(7));');
w.document.writeln('</script>');
//w.document.writeln('<script>');
//w.document.writeln('function execCmd(){');
//w.document.writeln('document.RKnotebook.setSource('+RKsrc+',alert("kkjkjkh"));');
//w.document.writeln('document.RKnotebook.evaluate(alert(7));');
//w.document.writeln('}');
//w.document.writeln('</script>');

w.document.writeln('</head>') ;

w.document.writeln('<body>');

/*w.document.writeln('	<script>');
w.document.writeln('	var notebook = RunKit.createNotebook({');
w.document.writeln('	    // the parent element for the new notebook');
w.document.writeln('	    element: document.getElementById("my-element");');
w.document.writeln('	    source: "alert("kjkjkjk");"');
w.document.writeln('	})');
w.document.writeln('	</script>');
*/
w.document.writeln('  <div class="container" name="the_container">');

w.document.writeln('    <div class="row">');
w.document.writeln('	  <div class="btn-group">');
w.document.writeln('	    <button type="button" class="btn btn-primary" >Resize icons</button>');

if(user.role=="admin"){
    w.document.writeln('	  <button type="button" class="btn btn-primary">Delete</button>');
    w.document.writeln('	  <div class="btn-group">');
    w.document.writeln('	    <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">');
    w.document.writeln('	    New <span class="caret"></span></button>');
    w.document.writeln('	    <ul class="dropdown-menu" role="menu">');
    w.document.writeln('	      <li><a href="#" onclick="upload()">File </a></li>');
    w.document.writeln('	      <li><a href="#">Directory</a></li>');
    w.document.writeln('	    </ul>');
} w.document.writeln('	  </div>');
w.document.writeln('      <input type="hidden" name="curr_directory" value="">');

w.document.writeln('      <script>');
w.document.writeln('      function upload(){');
w.document.writeln('          var x = document.createElement("input");');
w.document.writeln('          x.type="file";');
w.document.writeln('          x.multiple==true;');
w.document.writeln('          x.onchange=function(){');
w.document.writeln('          var txt = "";');
w.document.writeln('          if ("files" in x) {');
w.document.writeln('              if (x.files.length == 0) {');
w.document.writeln('                  txt = "Select one or more files.";');
w.document.writeln('              } else {');
w.document.writeln('                  for (var i = 0; i < x.files.length; i++) {');
w.document.writeln('                      txt += "<br><strong>" + (i+1) + ". file</strong><br>";');
w.document.writeln('                      var file = x.files[i];');
w.document.writeln('                      if ("name" in file) {');
w.document.writeln('                          txt += "name: " + file.name + "<br>";');
w.document.writeln('                      }');
w.document.writeln('                      if ("size" in file) {');
w.document.writeln('                          txt += "size: " + file.size + " bytes <br>";');
w.document.writeln('                      }');
w.document.writeln('                  }');
w.document.writeln('              }');
w.document.writeln('          } ');
w.document.writeln('          else {');
w.document.writeln('              if (x.value == "") {');
w.document.writeln('                  txt += "Select one or more files.";');
w.document.writeln('              } else {');
w.document.writeln('                  txt += "The files property is not supported by your browser!";');
w.document.writeln('                  txt += "<br>The path of the selected file: " + x.value; // If the browser does not support the files property, it will return the path of the selected file instead. ');
w.document.writeln('              }');
w.document.writeln('          }');
w.document.writeln('          };');
w.document.writeln('          document.getElementsByClassName("btn-group")[0].appendChild(x);');
w.document.writeln('          var btn = document.createElement("button");');
w.document.writeln('          document.getElementsByClassName("btn-group")[0].appendChild(btn);');
w.document.writeln('          var t = document.createTextNode("Upload");       // Create a text node');
w.document.writeln('          btn.appendChild(t); ');
//w.document.writeln('          btn.onclick=ftp_conn.put("/home/nizar/Templates/Cardio/index.html", "file.txt", function(hadError) {  if (!hadError)    console.log("File transferred successfully!");});');

w.document.writeln('      }');
w.document.writeln('      </script>');
// Close the dropdown menu if the user clicks outside of it
w.onclick = function(event) {
  if (!event.target.matches('.btn-group')) 
    if(document.getElementsByName('x').length>0){alert("djfkjfkj");
	document.getElementsByName('x')[0].remove();}
}
w.document.writeln('	</div>');

w.document.writeln('            <div class="col-lg-12">');
w.document.writeln('                <h1 class="page-header">Body document Gallery</h1>');
w.document.writeln('            </div>');
/*
w.document.writeln('            <div class="col-lg-3 col-md-4 col-xs-6 thumb" name="thumbnail">');
w.document.writeln('                <a class="thumbnail" href="#" filename=".."  filetype="dir"  onclick="dir_open(0)" id="th'+0+'">');
w.document.writeln('                    <img class="img-responsive img-rounded" src=../pdf_files/icons/parent.jpeg alt="">');
w.document.writeln('			<script name="open_file"> function file_open(idx) {if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="pdf") pdf_open(idx); else if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="dir") dir_open(idx); else alert("not pdf");} </script>');
w.document.writeln('                </a>');
w.document.writeln('            </div>');
*/
for(i=0;i<extract_files.length;i++) {
w.document.writeln('            <div class="col-lg-2 col-md-3 col-xs-4 thumb" name="thumbnail">');
w.document.writeln('                <a class="thumbnail" href="#" filename='+extract_files[i].filename+'  filetype='+extract_files[i].type+'  onclick="file_open('+i+')" id="th'+i+'" name="thumb_a">');
w.document.writeln('                    <img class="img-responsive img-rounded" name= "icon" src=../pdf_files/icons/'+extract_files[i].iconname+' alt="">');
w.document.writeln('    		<input type="hidden" name="nb" value='+i+'>');
w.document.writeln('			<script name="open_file"> function file_open(idx) {var filetype=document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype");if(filetype=="pdf") pdf_open(idx); else if(filetype=="dir") dir_open(idx); else alert("This is not a pdf file");} </script>');
w.document.writeln('                </a>');
w.document.writeln('            </div>');
}
w.document.writeln('  </div>');

//w.document.writeln('        <hr id="hr">');

w.document.writeln('    <!-- jQuery -->');
w.document.writeln('    <script src="../startbootstrap-thumbnail-gallery-master/js/jquery.js"></script>');

w.document.writeln('    <!-- Bootstrap Core JavaScript -->');
w.document.writeln('    <script src="../startbootstrap-thumbnail-gallery-master/js/bootstrap.min.js"></script>');

w.document.writeln('    <!-- Taffy Data Base -->');
w.document.writeln('	<script src="../taffy/taffy.js"> </script>');
w.document.writeln('	<script src="../taffy/db_users.js"> </script>');
w.document.writeln('	<script src="../taffy/db_files.js"> </script>');

w.document.writeln('    <!-- FTP tools -->');
w.document.writeln('	<script src="../FileSaver.js-master/FileSaver.js"> </script>');
//w.document.writeln('	<script src="../FileSaver.js-master/otherFileSaver.js"> </script>');
//w.document.writeln('	<script src="/home/nizar/Templates/node-ftps-master/index.js"> </script>');

w. document.writeln('	<script> function pdf_open(idx) {window.open("../pdf_files/"+document.getElementsByName("curr_directory")[0].value+document.getElementById("th"+idx).getAttribute("filename"));} </script>');
w.document.writeln('	<script src="js/file_open3.js"> </script>');

w.document.writeln('</body>');

}
