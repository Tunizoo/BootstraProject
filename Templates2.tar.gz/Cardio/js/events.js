var upload=require ("/home/nizar/Templates/Cardio/js/upload.js");
document.getElementById("dpd1").onclick=upload();

