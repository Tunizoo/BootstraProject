//function file_open(idx) {if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="pdf") pdf_open(idx); else if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="dir") dir_open(idx); else alert("not pdf");}

//function pdf_open(idx) {alert("_pdf");window.open("../pdf_files/"+document.getElementsByName("curr_directory")[0].value+document.getElementById("th"+idx).getAttribute("filename"));}
function pdf_open(idx) {window.open("../pdf_files/"+document.getElementsByName("curr_directory")[0].value+"/"+document.getElementById("th"+idx).getAttribute("filename"));}

function dir_open(idx) {
	var d=document.getElementsByName("curr_directory")[0].value;
	if(idx>0) {if(d!="") d=d+"/";d=d+document.getElementById("th"+idx).getAttribute("filename");}
	else {
	    var d=document.getElementsByName("curr_directory")[0].value;
            i=d.length;
	    do {
		var dd="";
	        for(j=0;j<i;j++)
		   dd=dd+d.charAt(j);
		d=dd;
		i--;
	    } while(d.charAt(i)!='/'&&i>=0);

	}
	    alert(d);
	var arr=document.getElementsByClassName("col-lg-2 col-md-3 col-xs-4 thumb");
	var la=arr.length;
	for(j=arr.length-1;j>=0;j--) arr[j].remove();	
	var extract_files=files({directory:d}).get();
	var l=extract_files.length;
	var inf=la,sup=l;
	if(l<la) {inf=l;sup=la;}
	var thumb =Array(l);
	var th_a  =Array(l);
	var th_img=Array(l);
	var script=Array(l);
/*	var th=document.getElementsByClassName('thumbnail
    for(i=0;i<=inf;i++) {
	//thumb[i]=th[i];
	th_a[i]=th[i];
	if(i==0){	
	    th_a[i].filename=document.getElementsByName("curr_directory")[0].value;
	    document.getElementsByName("curr_directory")[0].value=d;	
	    th_a[i].filetype="dir";
	} else {
	    th_a[i].filename=extract_files[i-1].filename;
	    th_a[i].filetype= extract_files[i-1].type;
	}alert(i);
	th_a[i].onclick="file_open("+i+")";
	th_img[i]=th_a[i].icon;
	if(i==0) th_img[i].src='../pdf_files/icons/parent.jpeg';
	else th_img[i].src= '../pdf_files/icons/'+extract_files[i-1].iconname;
	//script[i]=document.createElement('script
	//script[i].setAttribute('name','open_file
	//script[i].setAttribute('value','function file_open(idx) {if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="pdf") pdf_open(idx); else if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="dir") dir_open(idx); else alert("not pdf");}
    }

  if(l>la)
*/
	var i0=1;if(d=="")i0=0;	
    for(i=0;i<=l-(1-i0);i++) {
	thumb[i]=document.createElement('div');
	thumb[i].setAttribute('class', 'col-lg-2 col-md-3 col-xs-4 thumb');
	document.getElementsByClassName("container")[0].appendChild(thumb[i]);
	th_a[i]=document.createElement('a');
	th_a[i].setAttribute('class', 'thumbnail');
	th_a[i].setAttribute('name', 'thumbnail');
	if(i==0){
	    th_a[i].setAttribute('filename',document.getElementsByName("curr_directory")[0].value);
	    document.getElementsByName("curr_directory")[0].value=d;	
	    th_a[i].setAttribute('filetype',"dir");
	} if(i>=i0) {
	    th_a[i].setAttribute('filename',extract_files[i-i0].filename);
	    th_a[i].setAttribute('filetype', extract_files[i-i0].type);
	}
	th_a[i].setAttribute('href', '#');
	th_a[i].setAttribute('id', 'th'+i);
	th_a[i].setAttribute('onclick', 'file_open('+i+')');
	thumb[i].appendChild(th_a[i]);
	th_img[i]=document.createElement('img');
	th_img[i].setAttribute('class', 'img-responsive img-rounded');
	if(i==0) th_img[i].setAttribute('src', '../pdf_files/icons/parent.jpeg');
	if(i>=i0) th_img[i].setAttribute('src', '../pdf_files/icons/'+extract_files[i-i0].iconname);
	th_a[i].appendChild(th_img[i]);
	script[i]=document.createElement('script');
	script[i].setAttribute('name','open_file');
	script[i].setAttribute('value','function file_open(idx) {if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="pdf") pdf_open(idx); else if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="dir") dir_open(idx); else alert("not pdf");}');
	th_a[i].appendChild(script[i]);
    }
}

