//function file_open(idx) {if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="pdf") pdf_open(idx); else if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="dir") dir_open(idx); else alert("not pdf");}

//function pdf_open(idx) {alert("_pdf");window.open("../pdf_files/"+document.getElementsByName("curr_directory")[0].value+document.getElementById("th"+idx).getAttribute("filename"));}
function pdf_open(idx) {window.open("../pdf_files/"+document.getElementsByName("curr_directory")[0].value+document.getElementById("th"+idx).getAttribute("filename"));}

function dir_open(idx) {alert(document.getElementsByName("curr_directory")[0].value);
	var d=document.getElementsByName("curr_directory")[0].value;
	if(idx>0) {if(d!="") d=d+"/";d=d+document.getElementById("th"+idx).getAttribute("filename");}
	else {
	    var d=document.getElementsByName("curr_directory")[0].value;
	    do {
		i=d.length;
		var dd="";
	        for(j=0;j<i;j++)
		   dd=dd+d.charAt(j);
		d=dd;
		i--;
	    } while(d.charAt(i)!='/'&&i>0);
	    //document.getElementsByName("curr_directory")[0].value=d;	
	}
	alert(d);	
	var arr=document.getElementsByName("thumbnail");
	for(j=arr.length-1;j>=0;j--) arr[j].remove();

	var extract_files=files({directory:d}).get();
	var l=extract_files.length;
	var thumb=Array(l);
	var th_a =Array(l);
	var th_img=Array(l);
	var script=Array(l);
    for(i=0;i<=l;i++) {
	thumb[i]=document.createElement('div');
	thumb[i].setAttribute('class', 'col-lg-3 col-md-4 col-xs-6 thumb');
	document.getElementsByClassName("container")[0].appendChild(thumb[i]);
	th_a[i]=document.createElement('a');
	th_a[i].setAttribute('class', 'thumbnail');
	th_a[i].setAttribute('name', 'thumbnail');
	if(i==0){
	    th_a[i].setAttribute('filename',document.getElementsByName("curr_directory")[0].value);
	    document.getElementsByName("curr_directory")[0].value=d;	
	    th_a[i].setAttribute('filetype',"dir");
	} else {
	    th_a[i].setAttribute('filename',document.getElementsByName("curr_directory")[0].value+'/'+extract_files[i-1].filename);
	    th_a[i].setAttribute('filetype', extract_files[i-1].type);
	}
	alert(th_a[i].filename);
	th_a[i].setAttribute('href', '#');
	th_a[i].setAttribute('id', 'th'+i);
	th_a[i].setAttribute('onclick', 'file_open('+i+')');
	thumb[i].appendChild(th_a[i]);
	th_img[i]=document.createElement('img');
	th_img[i].setAttribute('class', 'img-responsive img-rounded');
	if(i==0) th_img[i].setAttribute('src', '../pdf_files/icons/parent.jpeg');
	else th_img[i].setAttribute('src', '../pdf_files/icons/'+extract_files[i-1].iconname);
	th_a[i].appendChild(th_img[i]);
	script[i]=document.createElement('script');
	script[i].setAttribute('name','open_file');
	script[i].setAttribute('value','function file_open(idx) {if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="pdf") pdf_open(idx); else if(document.getElementsByName("open_file")[idx].parentNode.getAttribute("filetype")=="dir") dir_open(idx); else alert("not pdf");}');
	th_a[i].appendChild(script[i]);
    }
}
