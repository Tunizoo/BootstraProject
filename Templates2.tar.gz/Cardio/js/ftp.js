function login(username,password,server) {

if (username && password && server) {
var ftpsite = "ftp://" + username + ":" + password + "@" + server;
window.location = ftpsite;
}
else {
alert("Please enter your username, password, and FTP server's address.");
   }
}

      // #####
      // ## Class::CSupportBase ()
      // ## return: none - constructor;
      function CSupportBase () {
         if (CSupportBase.caller != CSupportBase.getInstance) {
             throw new Error ("There is no public constructor for CSupportBase.");
         }

         this.m_plsWaitBoxCnt = 0;
         this.m_plsWaitBoxId = "divCSupportBasePleaseWait";
         this.m_isMobile = this.__isMobile();
         this.m_isIE = this.__isIE();
         this.m_isFirefox = this.__isFirefox();

         if (this.isFirefox()) {
            XMLDocument.prototype.selectNodes = function (xPath) {
               var oEvaluator = new XPathEvaluator();
               var oResult = oEvaluator.evaluate (xPath, this, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
               var aNodes = new Array();

               if (oResult != null) {
                  var oElement = oResult.iterateNext();

                  while(oElement) {
                     aNodes.push (oElement);

                     oElement = oResult.iterateNext();
                  }
               }

               return aNodes;
            }

            Element.prototype.selectNodes = function (xPath) {
               var oEvaluator = new XPathEvaluator();
               var oResult = oEvaluator.evaluate (xPath, this, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
               var aNodes = new Array();

               if (oResult != null) {
                  var oElement = oResult.iterateNext();

                  while(oElement) {
                     aNodes.push(oElement);

                     oElement = oResult.iterateNext();
                  }
               }

               return aNodes;
            }

            Element.prototype.selectSingleNode = function (xPath) {
               var oEvaluator = new XPathEvaluator();

               // FIRST_ORDERED_NODE_TYPE returns the first match to the xpath.
               var oResult = oEvaluator.evaluate (xPath, this, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);

               if (oResult != null) {
                  return oResult.singleNodeValue;
               } else {
                  return null;
               }              
            }
         }
      }

      //defining static property
      CSupportBase.__instance = null;


      // #####
      // ## Class::CSupportBase::getInstance ()
      // ## return: instance of CSupportBase class;
      CSupportBase.getInstance = function() {
         if (this.__instance == null) {
            this.__instance = new CSupportBase();
         }

         return this.__instance;
      }


      // #####
      // ## Class::CSupportBase::__isMobile ()
      // ## return: true || false;
      function CSupportBase_isMobile () {
         var isWinCE = navigator.userAgent.toLowerCase().indexOf('windows ce') > 0;
         var isSmartphone = navigator.userAgent.toLowerCase().indexOf('smartphone') > 0;

         if (isWinCE || isSmartphone) return true;

         return false;
      }


      // #####
      // ## Class::CSupportBase::__isFirefox ()
      // ## return: true || false;
      function CSupportBase_isFirefox () {
         var isFirefox = false;

         // window.XMLHttpRequest -- IE 7 supports this obj 
         if (navigator.userAgent.indexOf ("Firefox") != -1) isFirefox = true;

         return isFirefox;
      }


      // #####
      // ## Class::CSupportBase::__isIE ()
      // ## return: true || false;
      function CSupportBase_isIE () {
         if (window.ActiveXObject || navigator.userAgent.indexOf ("MSIE") != -1) return true;

         return false;
      }


      // #####
      // ## Class::CSupportBase::isFullIE ()
      // ## return: true || false;
      function CSupportBase_isFullIE () {
         if (this.isMobile() || this.isFirefox()) return false;

         if (this.isIE()) {
            if (navigator.userAgent.indexOf (" 4.") != -1) return false;

            return true;
         }

         return false;
      }


      // #####
      // ## Class::CSupportBase::toggleTopLayer (topLayerDivID, fShow) // fShow - true || false;
      // ## return: none;
      function CSupportBase_toggleTopLayer (topLayerDivID, fShow) { // return: none
         var oGuiElem = document.getElementById ? document.getElementById(topLayerDivID) : document.all[topLayerDivID];

         if (this.isEmpty(oGuiElem)) return;

         var oGuiElemStyle = oGuiElem.style;
         var divPos = this.getElemPos (oGuiElem);

         if (!fShow && this.isElemVisible (topLayerDivID) == false) return; // no action required

         var aSel = document.getElementsByTagName ("SELECT");
         for (var iSel = 0; iSel < aSel.length; iSel++) {
            if (aSel[iSel].name == oGuiElem.name) continue; // CXmlGuiMainArea !!!

            var elemPos = this.getElemPos (aSel[iSel]);

            if ( (elemPos.x > divPos.x && elemPos.x < (divPos.x + divPos.w)
               || (elemPos.x + elemPos.w) > divPos.x && (elemPos.x + elemPos.w) < (divPos.x + divPos.w)) 
               
               && (elemPos.y > divPos.y && elemPos.y < (divPos.y + divPos.h)
               || (elemPos.y + elemPos.h) > divPos.y && (elemPos.y + elemPos.h) < (divPos.y + divPos.h)) ) {

               if (fShow) {
                  if (this.isEmpty (aSel[iSel].tabTmpId)) {
                     aSel[iSel].prevVisibilityVal = aSel[iSel].style.visibility;
                     aSel[iSel].tabTmpId = iSel;
                  }
               } else {
                  aSel[iSel].prevVisibilityVal = "";
                  aSel[iSel].tabTmpId = "";
               }
               
               aSel[iSel].style.visibility = document.layers ? (fShow ? "hide" : aSel[iSel].prevVisibilityVal) : (fShow ? "hidden" : aSel[iSel].prevVisibilityVal);
            }
         }
         
         oGuiElemStyle.visibility = document.layers ? (fShow ? "show" : "hide") : (fShow ? "visible" : "hidden");
      }


      // #####
      // ## Class::CSupportBase::expandDiv (divId, expandHBy)
      // ## return: none;
      function CSupportBase_expandDiv (divId, expandHBy) {
         var oDiv = document.getElementById (divId);

         if (this.isEmpty (oDiv)) return;

         var currHeight = parseInt (oDiv.style.height);
         
         var expandBy = parseInt (expandHBy);

         if (currHeight + expandBy >= 200) oDiv.style.height = currHeight + expandBy;
      }


      // #####
      // ## Class::CSupportBase::isElemVisible (topLayerDivID);
      // ## return: top layer visibility status;
      function CSupportBase_isElemVisible (topLayerDivID) { // return: top layer visibility status
         if (this.isEmpty(topLayerDivID)) return false;

         var oGuiElem = document.getElementById ? document.getElementById(topLayerDivID) : document.all[topLayerDivID];
         
         if (this.isEmpty(oGuiElem)) return false;

         var oGuiElemStyle = oGuiElem.style;

         return document.layers ? (oGuiElemStyle.visibility == "show" ? true : false) : (oGuiElemStyle.visibility == "visible" ? true : false);
      }


      // #####
      // ## Class::CSupportBase::addEventHandler (oElement, eventName, func)
      // ## return: true || false;
      function CSupportBase_addEventHandler (oElement, eventName, func) { // return: true || false
         if (oElement.addEventListener) {
            return oElement.addEventListener (eventName, func, false);
         } else if (oElement.attachEvent) { 
            return oElement.attachEvent ("on" + eventName, func); 
         } else { 
            return false; 
         } 
      }


      // #####
      // ## Class::CSupportBase::pleaseWaitBox (fShow) // fShow - true || false;
      // ## return: none;
      function CSupportBase_pleaseWaitBox (fShow) { // return: none
         fShow ? this.m_plsWaitBoxCnt++ : (this.m_plsWaitBoxCnt > 0 ? this.m_plsWaitBoxCnt-- : "");

         var oPlsWaitBox = document.getElementById (this.m_plsWaitBoxId);

         if (this.isEmpty (oPlsWaitBox)) {
            var stylePlsWait = "position:absolute; top:300px; left:475px; width:300px; color:#000033; background-color:#DBEAF5; layer-background-color:#DBEAF5; z-index:99; visibility:hidden;";

            // insertion hides value of element <input type='password' .... [document.getElementById (Id).value], to fix issue call CSupportBase.getInstance().pleaseWaitBox(false) in onLoad method;
            document.body.innerHTML +=  "<div name='CSupport' id='"+ this.m_plsWaitBoxId +"' style='"+ stylePlsWait +"'><table width='100%' height='100' border='1'><tr><th>Please Wait ...</th></tr></table></div>";

            this.addEventHandler (window, 'scroll', this.scrollHandler);
         }

         if ((!fShow && this.m_plsWaitBoxCnt == 0) || fShow) { 
            this.toggleTopLayer (this.m_plsWaitBoxId, fShow);
         }
      }


      // #####
      // ## Class::CSupportBase::scrollHandler ();
      // ## return: none;
      function CSupportBase_scrollHandler () { // return: none
         var oSupportBase = CSupportBase.getInstance();

         var oPlsWaitBox = document.getElementById (oSupportBase.m_plsWaitBoxId);
         
         if (oSupportBase.isEmpty (oPlsWaitBox)) {
            return;
         }

         var style = oPlsWaitBox.style;

         if (oSupportBase.isElemVisible (oSupportBase.m_plsWaitBoxId)) {
            oSupportBase.toggleTopLayer (oSupportBase.m_plsWaitBoxId, false);

            style.top = document.body.scrollTop + 300;
            
            oSupportBase.toggleTopLayer (oSupportBase.m_plsWaitBoxId, true);
         }
      }


      // #####
      // ## Class::CSupportBase::getElemPos (oElem)
      // ## return: actual elem position in a document;
      function CSupportBase_getElemPos (oElem) { // return: actual elem position in a document
         var left = 0;
         var top = 0;
         var elemWidth = oElem.offsetWidth;
         var elemHeight = oElem.offsetHeight;

         while (oElem.offsetParent) {
            left += oElem.offsetLeft;
            top += oElem.offsetTop;
            oElem = oElem.offsetParent;
         }

         left += oElem.offsetLeft;
         top += oElem.offsetTop;

         return {
            x:left,
            y:top,
            w:elemWidth,
            h:elemHeight
         };
      }


      // #####
      // ## Class::CSupportBase::isEmpty (val)
      // ## return: true || false;
      function CSupportBase_isEmpty (val) {
         if (typeof (val) == "object" && val != null) return false;

         if (typeof (val) == "object" && val == undefined) return true;

         if (val == "" || val == undefined || val == null) return true;

         return false;
      }


      // #####
      // ## Class::CSupportBase::getRequestObj ()
      // ## return: Microsoft.XMLHTTP object;
      function CSupportBase_getRequestObj () {
         var oHttpRequest;

         try {
            if (window.XMLHttpRequest && !(window.ActiveXObject)) {
               oHttpRequest = new XMLHttpRequest();
            } else if (window.ActiveXObject) { // if IE/Windows
               oHttpRequest = new ActiveXObject ("Microsoft.XMLHTTP");
            }
         } catch (exp) {
            throw new Error ("In order for this application to work you need to allow ActiveX control to run.");
         }
         
         return oHttpRequest;
      }


      // #####
      // ## Class::CSupportBase::getXmlNodeValueSafe (oNode [, bDecodeURI])
      // ## return: node value || if node does not exists it will return "";
      function CSupportBase_getXmlNodeValueSafe (oNode, bDecodeURI) { // return: node value || ""
         if (this.isEmpty (oNode)) return "";

         bDecodeURI = bDecodeURI == true ? true : false;

         if (this.isFirefox()) {
            if (!this.isEmpty (oNode.firstChild)) return bDecodeURI == true ? decodeURI (oNode.firstChild.nodeValue) : oNode.firstChild.nodeValue;
            else return bDecodeURI == true ? decodeURI (oNode.singleNodeValue) : oNode.singleNodeValue;
         }

         if (this.isIE()) return bDecodeURI == true ? decodeURI (oNode.text) : oNode.text;
      }


      CSupportBase.prototype.isMobile = function () {
         return this.m_isMobile;
      }


      CSupportBase.prototype.isFirefox = function () {
         return this.m_isFirefox;
      }


      CSupportBase.prototype.isIE = function () {
         return this.m_isIE;
      }


      CSupportBase.prototype.__isMobile = CSupportBase_isMobile;
      CSupportBase.prototype.__isFirefox = CSupportBase_isFirefox;
      CSupportBase.prototype.__isIE = CSupportBase_isIE;
      CSupportBase.prototype.isFullIE = CSupportBase_isFullIE;
      CSupportBase.prototype.toggleTopLayer = CSupportBase_toggleTopLayer;
      CSupportBase.prototype.expandDiv = CSupportBase_expandDiv;
      CSupportBase.prototype.isElemVisible = CSupportBase_isElemVisible;
      CSupportBase.prototype.addEventHandler = CSupportBase_addEventHandler;
      CSupportBase.prototype.pleaseWaitBox = CSupportBase_pleaseWaitBox;
      CSupportBase.prototype.scrollHandler = CSupportBase_scrollHandler;
      CSupportBase.prototype.getElemPos = CSupportBase_getElemPos;
      CSupportBase.prototype.isEmpty = CSupportBase_isEmpty;
      CSupportBase.prototype.getRequestObj = CSupportBase_getRequestObj;
      CSupportBase.prototype.getXmlNodeValueSafe = CSupportBase_getXmlNodeValueSafe;
      // ## /Class::CSupportBase
      // #####
   </script>

   <script type="text/javascript" >
      // #####
      // ## Class::CXmlGui (xmlFilePath, xmlFileName, dataSetXPath, varNameAssignTo [, guiName, bEncodeURI])
      // ## return: none - constructor;
      function CXmlGui (xmlFilePath, xmlFileName, dataSetXPath, varNameAssignTo, guiName, bEncodeURI) {
         var oSupport = CSupport.getInstance();

         if (oSupport.isEmpty (xmlFilePath) || oSupport.isEmpty (xmlFileName) || oSupport.isEmpty (dataSetXPath) || oSupport.isEmpty (varNameAssignTo)) {
            throw new Error ("One of required parameters is empty: xmlFilePath, xmlFileName, dataSetXPath, varNameAssignTo.");
         }

         CXmlDataFile.apply (this, [xmlFilePath, xmlFileName, dataSetXPath, bEncodeURI]);

         this.m_guiName = oSupport.isEmpty (guiName) ? "CXmlGuiMainArea" : guiName;
         this.m_varNameAssignTo = varNameAssignTo;
         

         this.m_aGuiObjDisableByAction = new Array(); // required html attribute: disableByAction='true'
         this.m_hTrackChanges = new Array ();

         // Table's Drag and Drop logic
         this.m_oRowDragged = null;
         this.m_rowDraggedOrigIndex = 0;
         this.m_prevRowIndx = 0;
         this.m_dataRowsIndxOffset = 0; // to ignore header rows, first cell in the row should be "th";

         this.addTableEventHandlers ("table");

         // !!! customizing CXmlDataFile methods
         CXmlGui.prototype.__saveXml = CXmlDataFile.prototype.saveXml;
         CXmlGui.prototype.saveXml = CXmlGui_saveXml;
      }

      // CXmlGui is a child of CXmlDataFile
      CXmlGui.prototype = new CXmlDataFile ();
      CXmlGui.prototype.constructor = CXmlGui;
      CXmlGui.prototype.parent = CXmlDataFile;


      // #####
      // ## Class::CXmlGui::nextXmlDataSet (direction)
      // ## return: 0 - ok;
      function CXmlGui_nextXmlDataSet (direction) { // return: 0 - ok
         var oSupport = CSupport.getInstance();
         var guiObjIndx;

         this.m_currDataSetIndx += direction;

         if (this.m_currDataSetIndx < 0) this.m_currDataSetIndx = 0;
         if (this.m_currDataSetIndx >= this.m_xmlDataSetsCurrCnt) this.m_currDataSetIndx = this.m_xmlDataSetsCurrCnt - 1;

         if (this.m_currDataSetIndx < 0) this.resetXmlDataSet();

         // processing htmlTag: input
         this.nextXmlDataSetProcessSingleTag ("input");

         // processing htmlTag: div
         this.nextXmlDataSetProcessListTag ("div");

         // processing htmlTag: table
         this.nextXmlDataSetProcessListTag ("table");

         // processing htmlTag: select (to populate options and set value to it corresponding index)
         this.nextXmlDataSetProcessListTag ("select");
         
         // processing htmlTag: span
         this.nextXmlDataSetProcessSingleTag ("span");

         return 0;
      }


      // #####
      // ## Class::CXmlGui::nextXmlDataSetProcessSingleTag (tagName)
      // ## tagName supported: span, input
      // ## return: none;
      function CXmlGui_nextXmlDataSetProcessSingleTag (tagName) { // return: none
         var oGuiObjects = document.getElementsByTagName(tagName);
         var oSupport = CSupport.getInstance();

         for (guiObjIndx = 0; guiObjIndx < oGuiObjects.length; guiObjIndx++) {
            var guiObjectId = oGuiObjects[guiObjIndx].id;
            if (oSupport.isEmpty (guiObjectId)) continue;

            if (!this.isCurrGuiElem (oGuiObjects[guiObjIndx])) continue;

            // ## required html attribute: disableByAction='true'
            if (oGuiObjects[guiObjIndx].disableByAction == "true") {
               this.m_aGuiObjDisableByAction[guiObjectId] = "";
            }

            if (oGuiObjects[guiObjIndx].nextXmlDataSetExclude == "true") continue;

            var xmlPath = oGuiObjects[guiObjIndx].xmlPath;
            if (xmlPath == undefined) continue;

            var oNode = this.getXmlDataSetSingleNode (this.m_currDataSetIndx, xmlPath);
            var htmlValue = this.getNodeValueSafe (oNode);

            if (tagName == "input") oGuiObjects[guiObjIndx].value = htmlValue;
            else oGuiObjects[guiObjIndx].innerHTML = htmlValue;

         }
      }


      // #####
      // ## Class::CXmlGui::nextXmlDataSetProcessListTag (tagName)
      // ## tagName supported: div, table, select
      // ## return: none;
      function CXmlGui_nextXmlDataSetProcessListTag (tagName) { // return: none
         var oGuiObjects = document.getElementsByTagName(tagName);
         var oSupport = CSupport.getInstance();

         for (var guiObjIndx = 0; guiObjIndx < oGuiObjects.length; guiObjIndx++) {
            var guiObjectId = oGuiObjects[guiObjIndx].id;
            var guiObjectXmlPath = oGuiObjects[guiObjIndx].xmlPath;

            if (oSupport.isEmpty (guiObjectId)) continue;
            if (oSupport.isEmpty (guiObjectXmlPath)) continue;
            if (!this.isCurrGuiElem (oGuiObjects[guiObjIndx])) continue;

            // ## required html attribute: disableByAction='true'
            if (oGuiObjects[guiObjIndx].disableByAction == "true") {
               this.m_aGuiObjDisableByAction[guiObjectId] = "";
            }

            if (oGuiObjects[guiObjIndx].nextXmlDataSetExclude == "true") continue;

            if (tagName == "select") {
               var oSelect = oGuiObjects[guiObjIndx];

               if (oSelect.setOptsOnce != "true") {
                  oGuiObjects[guiObjIndx].options.length = 0;
                  oGuiObjects[guiObjIndx].options[oGuiObjects[guiObjIndx].options.length] = new Option("", "", false, false);

                  var oNodes = this.getGuiObjXmlNodes (guiObjectId);
                  if (oSupport.isEmpty (oNodes)) continue;

                  for (var iNode = 0; iNode < oNodes.length; iNode++) {
                     var value = this.getNodeValueSafe (oNodes[iNode]);

                     oGuiObjects[guiObjIndx].options[oGuiObjects[guiObjIndx].options.length] = new Option (value, iNode, false, false);
                  }
               }

               var oNode = this.getXmlDataSetSingleNode (this.m_currDataSetIndx, guiObjectXmlPath);
               var value = this.getNodeValueSafe (oNode);

               if (oSelect.length == 2 && value == "") value = "false";
               oSelect.value = value;
            } else this.updateDivSection (guiObjectId);
         }
      }


      // #####
      // ## Class::CXmlGui::isCurrGuiElem (oElem)
      // ## return: true || false;
      function CXmlGui_isCurrGuiElem (oElem) { // return: true || false
         var oSupport = CSupport.getInstance();

         if (oSupport.isEmpty (oElem.name) && this.m_guiName == "CXmlGuiMainArea") {
         } else if ((oSupport.isEmpty (oElem.name) && this.m_guiName != "CXmlGuiMainArea") || oElem.name != this.m_guiName) return false;

         return true;
      }


      // #####
      // ## Class::CXmlGui::resetXmlDataSet ()
      // ## return: 0 - ok;
      function CXmlGui_resetXmlDataSet () { // return: 0 - ok
         this.m_oXmlDomObj = new ActiveXObject ("Microsoft.XMLDOM");
         this.makeXmlPath (this.m_oXmlDomObj, this.m_dataSetXPath, true);
         this.m_colXmlDataSets = this.m_oXmlDomObj.selectNodes (this.m_dataSetXPath);
         this.m_xmlDataSetsCurrCnt = this.m_colXmlDataSets.length;
         this.m_xmlDataSetsOrigCnt = this.m_xmlDataSetsCurrCnt;

         this.m_hTrackChanges = new Array();
         this.m_fXmlChanged = false;

         this.nextXmlDataSet (1);
      }

      // #####
      // ## Class::CXmlGui::getInputTypeElems (oDivSection)
      // ## return: array of input elems;
      // ##
      // !!! HELP !!!
      // ## when adding new input type/elem don't forget to change the getInputTypeElemIndx method for itElemIndxOffset.
      function CXmlGui_getInputTypeElems (oDivSection) { // return: array of input elems
         var oSupport = CSupport.getInstance();
         var aInputTypeElems = null;
         var aXmlPaths = null;

         if (oDivSection.inputType == "itNone") {
            aInputTypeElems = Array (1);
            aInputTypeElems[0] = "n";
         } else if (oDivSection.inputType == "itActiveRemove") {
            aXmlPaths = oDivSection.xmlSubTags.split("|");

            aInputTypeElems = Array (aXmlPaths.length + 1); 
            aInputTypeElems[0] = "a";
            aInputTypeElems[1] = "r";
         } else if (oDivSection.inputType == "itMultiVals") {
            aXmlPaths = oDivSection.xmlSubTags.split("|");
            
            aInputTypeElems = Array (aXmlPaths.length + 1); 
            aInputTypeElems[0] = "r";
         } else if (oDivSection.inputType == "itMultiValsActive") {
            aXmlPaths = oDivSection.xmlSubTags.split("|");
            
            aInputTypeElems = Array (aXmlPaths.length + 1); 
            aInputTypeElems[0] = "r";
            aInputTypeElems[aXmlPaths.length] = "a";
         } else if (oDivSection.inputType == "itMultiValsLineNumActive") {
            aXmlPaths = oDivSection.xmlSubTags.split("|");
            
            aInputTypeElems = Array (aXmlPaths.length + 2); 
            aInputTypeElems[0] = "#";
            aInputTypeElems[1] = "r";
            aInputTypeElems[aXmlPaths.length + 1] = "a";
         } else if (oDivSection.inputType == "itMultiValsLineNumActiveSelect") {
            aXmlPaths = oDivSection.xmlSubTags.split("|");
            
            aInputTypeElems = Array (aXmlPaths.length + 3); 
            aInputTypeElems[0] = "#";
            aInputTypeElems[1] = "r";
            aInputTypeElems[aXmlPaths.length + 1] = "a";
            aInputTypeElems[aXmlPaths.length + 2] = "s";
         } else if (!oSupport.isEmpty (oDivSection.xmlSubTags)) {
            aXmlPaths = oDivSection.xmlSubTags.split("|");

            aInputTypeElems = Array (aXmlPaths.length + 1); 
            aInputTypeElems[0] = "r";
         } else {      
            aInputTypeElems = Array (2); 
            aInputTypeElems[0] = "r";
         }

         return aInputTypeElems;
      }


      // #####
      // ## Class::CXmlGui::getInputTypeElemIndx (oDivSection, elemType)
      // ## return: input elem indx;
      function CXmlGui_getInputTypeElemIndx (oDivSection, elemType) { // return: input elem indx
         var aInputTypeElems = this.getInputTypeElems (oDivSection);
         var itElemIndxOffset = 0;

         for (var elemIndx in aInputTypeElems) {
            if (aInputTypeElems[elemIndx] == elemType) return (elemIndx - itElemIndxOffset);
            else if (aInputTypeElems[elemIndx] == "r") itElemIndxOffset++; 
            else if (aInputTypeElems[elemIndx] == "#") itElemIndxOffset++; 
         }

         return -1;
      }


      // #####
      // ## Class::CXmlGui::getElemErrMsg (elemId)
      // ## return: error message;
      // ##
      // !!! HELP !!!
      // ## <select id='frmExmplOpts' xmlPath='./ExmplFormat' msgErr='This is a test error message.' onChange='oGui.changeDataByGuiObject(this);'>
      function CXmlGui_getElemErrMsg (elemId) { // return: error message
         var oElem = document.getElementById(elemId);

         if (CSupport.getInstance().isEmpty(oElem)) return "";

         return oElem.msgErr;
      }


      // #####
      // ## Class::CXmlGui::getElemDefVal (elemId)
      // ## return: default value;
      // ##
      // !!! HELP !!!
      // ## <select id='frmExmplOpts' xmlPath='./ExmplFormat' defVal='F1' msgErr='This is a test error message.' onChange='oGui.changeDataByGuiObject(this);'>
      function CXmlGui_getElemDefVal (elemId) { // return: default value
         var oElem = document.getElementById(elemId);

         if (CSupport.getInstance().isEmpty(oElem)) return "";

         return oElem.defVal;
      }


      // #####
      // ## Class::CXmlGui::updateDivSection (sectionNameToModif)
      // ## return: 0 - ok || 1 - xmlPath is empty;
      function CXmlGui_updateDivSection (sectionNameToModif) { // return: 0 - ok || 1 - xmlPath is empty
         var oDivSection = document.getElementById (sectionNameToModif);
         var oSupport = CSupport.getInstance();
         var xmlPath = oDivSection.xmlPath;
         var str = "";

         if (oSupport.isEmpty (xmlPath)) return 1;

         if (oDivSection.tagName == "TABLE") {
            this.m_dataRowsIndxOffset = 0;

            for (var rowIndx = oDivSection.rows.length - 1; rowIndx >= 0 ; rowIndx--) {
               var oCell = oDivSection.rows[rowIndx].cells[0];

               if (oCell.tagName == "TH") this.m_dataRowsIndxOffset++;
               else oDivSection.deleteRow (rowIndx);
            }
         }

         var aInputTypeElems = this.getInputTypeElems (oDivSection);

         var aXmlPaths = null;
         if (!oSupport.isEmpty (oDivSection.xmlSubTags)) {
            aXmlPaths = oDivSection.xmlSubTags.split("|");
         }

         var oNodes = this.getCurrXmlDataSet().selectNodes(xmlPath);

         if (oNodes[0] != undefined) {
            for (var i = 0; i < oNodes.length; i++) {
               var itElemIndxOffset = 0;
               
               if (oNodes[i].text) {
                  var oNewRow, oNewCell, text, spacer, oNode;

                  if (oDivSection.tagName == "TABLE") {
                     oNewRow = oDivSection.insertRow ();
                  }
                     
                  for (var itElemIndx = 0; itElemIndx < aInputTypeElems.length; itElemIndx++) {
                     spacer = "";

                     if (aInputTypeElems[itElemIndx] == "r" ) {
                        text = "<acronym title='Click here to remove from List'><input type='checkbox' onClick='"
                           + this.m_varNameAssignTo +".processCheckmarkChanges(\"removeNode\", "+ sectionNameToModif +", "+ i +");'/></acronym>";

                        itElemIndxOffset++;
                     } else if (aInputTypeElems[itElemIndx] == "#" ) {
                        text = i + 1;
                        itElemIndxOffset++;
                     } else if (aInputTypeElems[itElemIndx] == "s" ) {
                        text = "<acronym title='Click here to select item'><input type='checkbox'/></acronym>";
                     } else if (aInputTypeElems[itElemIndx] == "a" ) {
                        var checkMarkStatus = "";
                        oNode = oNodes[i].selectSingleNode(aXmlPaths[itElemIndx - itElemIndxOffset]);

                        if (oNode != undefined) {
                           checkMarkStatus = (oNode.text == "true" ? "checked" : "");
                        } else {
                           oNode = this.makeXmlPath(oNodes[i], aXmlPaths[itElemIndx - itElemIndxOffset]);
                           oNode.text = "false";
                        }

                        text = "<input type='checkbox' onClick='"
                           + this.m_varNameAssignTo +".processCheckmarkChanges(\"saveCheckStatus\", "+ sectionNameToModif +", "+ i +", "+ (itElemIndx - itElemIndxOffset) +");' "
                           + checkMarkStatus +"/>";
                     } else {
                        if (oSupport.isEmpty (aXmlPaths)) {
                           text = this.getNodeValueSafe (oNodes[i]);
                        } else {
                           oNode = oNodes[i].selectSingleNode(aXmlPaths[itElemIndx - itElemIndxOffset]);
                           text = this.getNodeValueSafe (oNode);
                           spacer = "&nbsp;&#8226;&nbsp;";
                        }
                     }

                     if (oSupport.isEmpty (text)) text = "&nbsp;";

                     if (oDivSection.tagName == "DIV") {
                        str += text + spacer;
                     } else {
                        oNewCell = oNewRow.insertCell ();
                        oNewCell.innerHTML = text;
                     }
                  }

                  if (oDivSection.tagName == "DIV") str += "<br/>";
                  else this.addTableRowEventHandlers (oNewRow, oDivSection.id);
               }
            }
         }

         if (oDivSection.tagName == "DIV") {
            document.getElementById(sectionNameToModif).innerHTML = str;
         }

         return 0;
      }


      // #####
      // ## Class::CXmlGui::getCurrDataSetChanges ()
      // ## return: hChanges a hash of changes where the key is GUI's element id;
      function CXmlGui_getCurrDataSetChanges () { // return: hChanges a hash of changes where the key is GUI's element id
         var hChanges = this.m_hTrackChanges[this.m_currDataSetIndx];

         if (CSupport.getInstance().isEmpty (hChanges)) return null;
         
         return hChanges;
      }


      // #####
      // ## Class::CXmlGui::setCurrDataSetChanges (hChanges)
      // ## return: none;
      function CXmlGui_setCurrDataSetChanges (hChanges) { // return: none
         this.m_hTrackChanges[this.m_currDataSetIndx] = hChanges;
      }


      // #####
      // ## Class::CXmlGui::changeDataByGuiObject (oGuiObject, bSaveOrigVal)
      // ## return: 0 - ok || 1 - xmlPath is empty;
      function CXmlGui_changeDataByGuiObject (oGuiObject, bSaveOrigVal) { // return: 0 - ok || 1 - xmlPath is empty
         if (oGuiObject.xmlPath == undefined) return 1;

         var oSupport = CSupport.getInstance();

         this.m_fXmlChanged = true;

         var oNode = this.getXmlDataSetSingleNode (this.m_currDataSetIndx, oGuiObject.xmlPath);
         var hChanges = this.getCurrDataSetChanges();

         if (bSaveOrigVal && (hChanges == null || oSupport.isEmpty (hChanges[oGuiObject.id]))) {
            if (oSupport.isEmpty (hChanges)) hChanges = new Array;
            hChanges[oGuiObject.id] = this.getNodeValueSafe (oNode);

            this.setCurrDataSetChanges (hChanges);
         }

         oNode.text = oGuiObject.value;

         return 0;
      }


      // #####
      // ## Class::CXmlGui::changeDataByDivSection (updatedDivSectionName, value, bCreateNewNode)
      // ## return: 0 - ok || 1 - xmlPath is empty;
      function CXmlGui_changeDataByDivSection (updatedDivSectionName, value, bCreateNewNode) { // return: 0 - ok || 1 - xmlPath is empty
         var oDivSection = document.getElementById (updatedDivSectionName);
         if (oDivSection.xmlPath == undefined) return 1;

         this.m_fXmlChanged = true;
         var oNode = undefined;

         if (bCreateNewNode == true) {
            var oSectionNodes = this.getCurrXmlDataSet().selectNodes (oDivSection.xmlPath);
            var oCurrSectionNode = undefined;
            var fFound = false;

            for (var i = 0; !fFound && i < oSectionNodes.length; i++) {
               var currSectionNodeText = oSectionNodes[i].text;

               if (currSectionNodeText == "") { oCurrSectionNode = oSectionNodes[i]; }
               else if (oDivSection.xmlSubTags != undefined && oDivSection.xmlSubTags != "") fFound = false;
               else if (currSectionNodeText == value) fFound = true;
            }

            if (!fFound) {
               var oSupport = CSupport.getInstance();

               if (!oSupport.isEmpty (oDivSection.xmlSubTags)) {
                  if (oCurrSectionNode == undefined) {
                     oNode = this.makeXmlPath (this.getCurrXmlDataSet(), oDivSection.xmlPath, bCreateNewNode);
                  } else {
                     oNode = oCurrSectionNode;
                  }

                  var aXmlPaths = oDivSection.xmlSubTags.split("|");
                  var activeElemIndx = this.getInputTypeElemIndx (oDivSection, "a");

                  var aDataSource = value.split(";");

                  for (var pathIndx in aXmlPaths) {
                     var newSubNode = this.makeXmlPath (oNode, aXmlPaths[pathIndx], true);

                     if (pathIndx == activeElemIndx) newSubNode.text = "true";
                     else if (aDataSource.length == 1) newSubNode.text = value;
                     else {
                        var subVal = document.getElementById (aDataSource[pathIndx]).value;
                        newSubNode.text = subVal;
                     }
                  }
               } else if (oCurrSectionNode != undefined) {
                  oCurrSectionNode.text = value;
               } else {
                  oNode = this.makeXmlPath (this.getCurrXmlDataSet(), oDivSection.xmlPath, bCreateNewNode);
                  oNode.text = value;
               }
            }
            
         } else {
            var oNode = this.getXmlDataSetSingleNode (this.m_currDataSetIndx, oDivSection.xmlPath);
            oNode.text = value;
         }

         return 0;
      }


      // #####
      // ## Class::CXmlGui::saveXml ([fileLoc])
      // ## return: 0 - ok || 1 - user cancel request;
      function CXmlGui_saveXml (fileLoc) { // return: 0 - ok || 1 - user cancel request
         var dlgErrMsg = "Are you sure you want to save changes?";

         if (!confirm (dlgErrMsg)) return 1;

         var oSupport = CSupport.getInstance ();

         if (oSupport.isEmpty (fileLoc)) fileLoc = this.m_xmlFileLoc;
         

         var ret = this.__saveXml (fileLoc);

         if (oSupport.isEmpty (ret)) {
            this.m_fXmlChanged = false;

            alert ("File saved successfully.");
         } else {
            alert (ret);

            return 2;
         }

         return 0;
      }


      // #####
      // ## Class::CXmlGui::addNodeToXmlDataSet (sourceData, sectionNameToModif, maxSize, nodeType)
      // ## return: none;
      // ##
      // !!! HELP !!!
      // ## nodeType: "folder" || "fileNameOnly" || ""
      // ##
      // ## for itMultiVals and etc. sourceData could keep list of sources separated by ";"
      // ## as example: oGui.addNodeToXmlDataSet("inptFileDesc;inptFileId;frmFileTypeOpts;frmFileDownloadableOpts", "tblFileList");
      function CXmlGui_addNodeToXmlDataSet (sourceData, sectionNameToModif, maxSize, nodeType) { // return: none
         var oSupport = CSupport.getInstance ();
         var guiObj = null;
         var str;

         this.m_fXmlChanged = true;

         if (!oSupport.isEmpty (sourceData)) guiObj = document.getElementById (sourceData);

         if (oSupport.isEmpty (guiObj)) {
            str = sourceData;
         } else {
            str = guiObj.value;
         }

         if (nodeType == "folder" || nodeType == "fileNameOnly") {
            str = str.replace (/\\+/g, "\\");

            // to keep Env variables
            var aPath = str.split("\\");
            var aPathExpand = new Array ();

            for (var pElem in aPath) aPathExpand[pElem] = oSupport.getShellObj().ExpandEnvironmentStrings (aPath[pElem]);

            var expandFileLoc = aPathExpand.join ("\\");
            expandFileLoc = expandFileLoc.replace (/\\+/g, "\\");

            if (oSupport.getFsoObj().FileExists (expandFileLoc)) aPath.pop();
            // /to keep Env variables

            str = aPath.join ("\\");

            if (nodeType == "fileNameOnly") {
               str = expandFileLoc.replace (str +"\\", "");
            }
         }

         if (str != "" || (maxSize == 1 && str == "")) {
            var oDivSection = document.getElementById(sectionNameToModif);
            var oSectionNodes = this.getCurrXmlDataSet().selectNodes(oDivSection.xmlPath);

            if (maxSize == undefined || maxSize < 1 || oSectionNodes.length == 0 || oSectionNodes.length < maxSize) {
               this.changeDataByDivSection (sectionNameToModif, str, true);
            } else {
               this.changeDataByDivSection (sectionNameToModif, str, false);
            }

            this.updateDivSection (sectionNameToModif);
         }
      }


      // #####
      // ## Class::CXmlGui::populateMoveBeforeDropDown (elemId, xmlPath)
      // ## return: none;
      function CXmlGui_populateMoveBeforeDropDown (elemId, xmlPath) { // return: none
         var oMoveBeforeOpts = document.getElementById (elemId);
         var indxCurrTitle = -1;

         oMoveBeforeOpts.options.length = 0;

         for (var setIndx = 0; setIndx < this.m_colXmlDataSets.length; setIndx++) {
            if (this.m_currDataSetIndx == setIndx) {
               indxCurrTitle = setIndx;
            } else {
               if (indxCurrTitle + 1 > 0) {
                  indxCurrTitle = -1;
               } else {
                  var oNode = this.getXmlDataSetSingleNode (setIndx, xmlPath);
                  oMoveBeforeOpts.options[oMoveBeforeOpts.options.length] = new Option(this.getNodeValueSafe(oNode), setIndx, false, false);
               }
            }
         }
      }


      // #####
      // ## Class::CXmlGui::addShortLocNode (sourceData, sectionNameToModif, rootPath, maxSize, nodeType)
      // ## return: none;
      // ##
      // ## nodeType: "folder" || ""
      function CXmlGui_addShortLocNode (sourceData, sectionNameToModif, rootPath, maxSize, nodeType) { // return: none
         var oSupport = CSupport.getInstance ();
         var oShell = oSupport.getShellObj();

         var expandRootPath = rootPath.replace (/\\+/g, "\\");
         var str = document.getElementById(sourceData).value;
         str = str.replace (/\\+/g, "\\");

         expandRootPath = oShell.ExpandEnvironmentStrings (expandRootPath);
         str = oShell.ExpandEnvironmentStrings (str);

         // to remove selected file name
         if (nodeType == "folder" && oSupport.getFsoObj().FileExists (str)) {
            var aPath = str.split ("\\");
            var fn =  aPath.pop();

            str = str.replace ("\\"+ fn, "");
         }

         str = str.replace (expandRootPath +"\\", "");

         this.addNodeToXmlDataSet (str, sectionNameToModif, maxSize);
      }


      // #####
      // ## Class::CXmlGui::processCheckmarkChanges (funcRequested, sectionNameToModif, nodeIndx, xmlPathsIndx)
      // ## return: 0 - ok || 1 - xmlPath is empty;
      function CXmlGui_processCheckmarkChanges (funcRequested, sectionNameToModif, nodeIndx, xmlPathsIndx) { // return: 0 - ok || 1 - xmlPath is empty
         var oDivSection = document.getElementById (sectionNameToModif.id);
         var xmlPath = oDivSection.xmlPath;
         var str = "";

         if (xmlPath == undefined) return 1;

         this.m_fXmlChanged = true;

         var oNodes = this.getCurrXmlDataSet().selectNodes(xmlPath);
         if (oNodes[0] != undefined && nodeIndx < oNodes.length) {
            if (funcRequested == "removeNode") {
               oNodes[nodeIndx].parentNode.removeChild (oNodes[nodeIndx]);
            } else if (funcRequested == "saveCheckStatus") {
               var aXmlPaths = oDivSection.xmlSubTags.split("|");

               var oNode = oNodes[nodeIndx].selectSingleNode (aXmlPaths[xmlPathsIndx]);
               if (oNode.text == "true") oNode.text = "false";
               else oNode.text = "true";
            }
         }

         this.updateDivSection (sectionNameToModif.id);

         return 0;
      }


      // #####
      // ## Class::CXmlGui::getStatGuiObjDisableByAction ()
      // ## required html attribute: disableByAction='true'
      // ## return: none;
      function CXmlGui_getStatGuiObjDisableByAction () { // return: none
         for (var guiObjIndx in this.m_aGuiObjDisableByAction) {
            if (!CSupport.getInstance().isEmpty (document.getElementById (guiObjIndx))) {
               this.m_aGuiObjDisableByAction[guiObjIndx] = document.getElementById (guiObjIndx).disabled;
            }
         }
      }


      // #####
      // ## Class::CXmlGui::setStatGuiObjDisableByAction (stat)
      // ## required html attribute: disableByAction='true'
      // ## return: none;
      function CXmlGui_setStatGuiObjDisableByAction (stat) { // return: none
         for (var guiObjIndx in this.m_aGuiObjDisableByAction) {
            CSupport.getInstance().disableAccess (guiObjIndx, stat);
         }
      }


      // #####
      // ## Class::CXmlGui::revertStatGuiObjDisableByAction ()
      // ## required html attribute: disableByAction='true'
      // ## return: none;
      function CXmlGui_revertStatGuiObjDisableByAction () { // return: none
         for (var guiObjIndx in this.m_aGuiObjDisableByAction) {
            CSupport.getInstance().disableAccess (guiObjIndx, this.m_aGuiObjDisableByAction[guiObjIndx]);
         }
      }


      // #####
      // ## Class::CXmlGui::getGuiObjXmlPath (guiObjId)
      // ## return: xmlPath || "";
      function CXmlGui_getGuiObjXmlPath (guiObjId) { // return: xmlPath || ""
         var oGui = document.getElementById (guiObjId);

         if (oGui == null) return "";

         return oGui.xmlPath;
      }


      // #####
      // ## Class::CXmlGui::getGuiObjXmlNode (guiObjId)
      // ## return: oNode - ok || null;
      function CXmlGui_getGuiObjXmlNode (guiObjId) { // return: oNode - ok || null
         var xmlPath = this.getGuiObjXmlPath (guiObjId);

         if (xmlPath == "") return null;

         var oNode = this.getXmlDataSetSingleNode (this.m_currDataSetIndx, xmlPath);
         if (oNode == undefined) return null;

         return oNode;
      }


      // #####
      // ## Class::CXmlGui::getGuiObjXmlNodes (guiObjId)
      // ## return: oNodes - ok || null;
      function CXmlGui_getGuiObjXmlNodes (guiObjId) { // return: oNode - ok || null
         var xmlPath = this.getGuiObjXmlPath (guiObjId);

         if (xmlPath == "") return null;

         var oNodes = this.getCurrXmlDataSet().selectNodes (xmlPath);
         if (oNodes == undefined) return null;

         return oNodes;
      }


      // Table's Drag and Drop logic

      // #####
      // ## Class::CXmlGui::addTableRowEventHandlers (oRow, tableId)
      // ## return: none;
      function CXmlGui_addTableRowEventHandlers (oRow, tableId) { // return: none
         var self = this;

         oRow.style.cursor = "pointer";

         oRow.onmousedown = function () {
            var oElem = window.event.srcElement;
            if (oElem.tagName == 'INPUT') return true;

            self.m_oRowDragged = this;
            self.m_rowDraggedOrigIndex = this.rowIndex;

            return false;
         }

         oRow.onmouseup = function () {
            if (!CSupport.getInstance().isEmpty (self.m_oRowDragged)) {
               if (this.rowIndex == self.m_rowDraggedOrigIndex) {
                  self.m_oRowDragged.style.backgroundColor = 'transparent';
                  self.m_oRowDragged = null;

                  return true;
               }

               var oNodes = self.getGuiObjXmlNodes (tableId);
               var oNodeDragged = oNodes[self.m_rowDraggedOrigIndex - self.m_dataRowsIndxOffset];
               var rowBeforeIndx = this.rowIndex - self.m_dataRowsIndxOffset + 1;

               if (rowBeforeIndx < self.m_rowDraggedOrigIndex) rowBeforeIndx--; // going up

               oNodeDragged.parentNode.insertBefore (oNodeDragged, oNodes[rowBeforeIndx]);

               self.m_oRowDragged.style.backgroundColor = 'transparent';
               self.m_oRowDragged = null;
               self.m_fXmlChanged = true;

               self.updateDivSection (tableId);
            }
         }

         oRow.onmousemove = function () {
            if (!CSupport.getInstance().isEmpty (self.m_oRowDragged)) {
               var newRowIndx = this.rowIndex;

               if (newRowIndx != self.m_prevRowIndx) {
                  var oRowBefore = this.nextSibling;

                  if (newRowIndx < self.m_rowDraggedOrigIndex) oRowBefore = this; // going up

                  self.m_prevRowIndx = newRowIndx;
                  self.m_oRowDragged.style.backgroundColor = "#FFCCFF";
                  self.m_oRowDragged.parentNode.insertBefore (self.m_oRowDragged, oRowBefore);
               }

               return false;
            }
         }
      }


      // #####
      // ## Class::CXmlGui::addTableEventHandlers (tagName)
      // ## return: none;
      function CXmlGui_addTableEventHandlers (tagName) { // return: none
         var oGuiObjects = document.getElementsByTagName (tagName);
         var oSupport = CSupport.getInstance();

         for (var guiObjIndx = 0; guiObjIndx < oGuiObjects.length; guiObjIndx++) {
            var guiObjectId = oGuiObjects[guiObjIndx].id;
            var guiObjectXmlPath = oGuiObjects[guiObjIndx].xmlPath;

            if (oSupport.isEmpty (guiObjectId)) continue;
            if (oSupport.isEmpty (guiObjectXmlPath)) continue;
            if (!this.isCurrGuiElem (oGuiObjects[guiObjIndx])) continue;

            var self = this;
            var id = oGuiObjects[guiObjIndx].id

            oGuiObjects[guiObjIndx].onmouseleave = function () {
               if (!CSupport.getInstance().isEmpty (self.m_oRowDragged)) {
                  self.m_oRowDragged.style.backgroundColor = 'transparent';
                  self.m_oRowDragged = null;

                  self.updateDivSection (id);
               }
            }
         }
      }


      CXmlGui.prototype.addTableEventHandlers = CXmlGui_addTableEventHandlers;
      CXmlGui.prototype.addTableRowEventHandlers = CXmlGui_addTableRowEventHandlers;
      CXmlGui.prototype.nextXmlDataSet = CXmlGui_nextXmlDataSet;
      CXmlGui.prototype.isCurrGuiElem = CXmlGui_isCurrGuiElem;
      CXmlGui.prototype.resetXmlDataSet = CXmlGui_resetXmlDataSet;
      CXmlGui.prototype.getElemErrMsg = CXmlGui_getElemErrMsg;
      CXmlGui.prototype.getElemDefVal = CXmlGui_getElemDefVal;
      CXmlGui.prototype.updateDivSection = CXmlGui_updateDivSection;
      CXmlGui.prototype.nextXmlDataSetProcessSingleTag = CXmlGui_nextXmlDataSetProcessSingleTag;
      CXmlGui.prototype.nextXmlDataSetProcessListTag = CXmlGui_nextXmlDataSetProcessListTag;
      CXmlGui.prototype.getCurrDataSetChanges = CXmlGui_getCurrDataSetChanges;
      CXmlGui.prototype.setCurrDataSetChanges = CXmlGui_setCurrDataSetChanges;
      CXmlGui.prototype.changeDataByGuiObject = CXmlGui_changeDataByGuiObject;
      CXmlGui.prototype.changeDataByDivSection = CXmlGui_changeDataByDivSection;
      CXmlGui.prototype.addNodeToXmlDataSet = CXmlGui_addNodeToXmlDataSet;
      CXmlGui.prototype.populateMoveBeforeDropDown = CXmlGui_populateMoveBeforeDropDown;
      CXmlGui.prototype.addShortLocNode = CXmlGui_addShortLocNode;
      CXmlGui.prototype.processCheckmarkChanges = CXmlGui_processCheckmarkChanges;
      CXmlGui.prototype.getStatGuiObjDisableByAction = CXmlGui_getStatGuiObjDisableByAction;
      CXmlGui.prototype.setStatGuiObjDisableByAction = CXmlGui_setStatGuiObjDisableByAction;
      CXmlGui.prototype.revertStatGuiObjDisableByAction = CXmlGui_revertStatGuiObjDisableByAction;
      CXmlGui.prototype.getGuiObjXmlPath = CXmlGui_getGuiObjXmlPath;
      CXmlGui.prototype.getGuiObjXmlNode = CXmlGui_getGuiObjXmlNode;
      CXmlGui.prototype.getGuiObjXmlNodes = CXmlGui_getGuiObjXmlNodes;
      CXmlGui.prototype.getInputTypeElems = CXmlGui_getInputTypeElems;
      CXmlGui.prototype.getInputTypeElemIndx = CXmlGui_getInputTypeElemIndx;
      // ## /Class::CXmlGui()
      // #####


      // #####
      // ## Class::CFtpFileManager ()
      // ## return: none - constructor;
      function CFtpFileManager () {
         if (CFtpFileManager.caller != CFtpFileManager.getInstance) {
             throw new Error ("There is no public constructor for CFtpFileManager.");
         }

         try {
            this.m_hFileInfoList = new Array ();
            this.m_fileCnt = 0;
            this.m_tmpLocalPath = "%TMP%";
            this.m_altTransport = {
               web:"webPath:",
               ftp:"remotePath:"
            };
         } catch (exp) {
            this.__instance = null;
         }
      }

      //defining static property
      CFtpFileManager.__instance = null;

      // #####
      // ## Class::CFtpFileManager::getInstance ()
      // ## return: instance of CFtpFileManager class;
      CFtpFileManager.getInstance = function() {
         if (this.__instance == null) {
            this.__instance = new CFtpFileManager();
         }

         return this.__instance;
      }


      // #####
      // ## Class::CFtpFileManager::addFile (localFileName, ftpHost, ftpUser, ftpPass, ftpPath [, ftpFileName, localPath, bKeepLocal])
      // ## return: oFileInfo;
      // ##
      // !!! HELP !!!
      // ## if ftpUser == m_altTransport.web then http mode
      function CFtpFileManager_addFile (localFileName, ftpHost, ftpUser, ftpPass, ftpPath, ftpFileName, localPath, bKeepLocal) { // return: oFileInfo
         var oSupport = CSupport.getInstance ();

         if (oSupport.isEmpty (localFileName) || oSupport.isEmpty (ftpHost)) {
             throw new Error ("Required parameters are empty: localFileName or ftpHost.");
         }

         if (oSupport.isEmpty (localPath)) localPath = this.m_tmpLocalPath;

         if (bKeepLocal != true) bKeepLocal = false;

         var localPathExpand = oSupport.getShellObj().ExpandEnvironmentStrings (localPath);
         var localLocExpand = localPathExpand +"\\"+ localFileName;

         ftpFileName = oSupport.isEmpty (ftpFileName) ? localFileName : ftpFileName;

         var fileInfoKey = localFileName +"_"+ ftpHost +"_"+ ftpUser +"_"+ ftpPath +"_"+ ftpFileName +"_"+ localPathExpand; 

         if (oSupport.isEmpty (this.m_hFileInfoList[fileInfoKey])) {
            var oFileInfo = {
               fileName: localFileName,
               ftpHost: ftpHost,
               ftpUser: ftpUser,
               ftpPass: ftpPass,
               ftpPath: ftpPath,
               ftpFileName: ftpFileName,
               fKeepLocal: bKeepLocal,

               fileId: ++this.m_fileCnt,
               localPath: localPath,
               localPathExpand: localPathExpand,
               fileStatus: "added" // added || missing || retrieved || placed || deleted;
            };

            this.m_hFileInfoList[fileInfoKey] = oFileInfo;
         }

         return this.m_hFileInfoList[fileInfoKey];
      }


      // #####
      // ## Class::CFtpFileManager::getFile (localFileName, ftpHost, ftpUser, ftpPass, ftpPath, ftpFileName)
      // ## return: oFileInfo;
      function CFtpFileManager_getFile (localFileName, ftpHost, ftpUser, ftpPass, ftpPath, ftpFileName) { // return: oFileInfo
         var oSupport = CSupport.getInstance ();

         var oFileInfo = this.addFile (localFileName, ftpHost, ftpUser, ftpPass, ftpPath, ftpFileName);

         if (oFileInfo.fileStatus == "added" || oFileInfo.fileStatus == "deleted" || oFileInfo.fileStatus == "missing") {
            if (this.m_altTransport.web == oFileInfo.ftpUser) { // AltTransport
               var fullUrl = oFileInfo.ftpHost;

               if (!oSupport.isEmpty (oFileInfo.ftpPath)) fullUrl += "/"+ oFileInfo.ftpPath;
               if (!oSupport.isEmpty (oFileInfo.ftpFileName)) fullUrl += "/"+ oFileInfo.ftpFileName;

               try {
                  var oReqObj = oSupport.getRequestObj();

                  oReqObj.open ("GET", fullUrl, false);
                  //oReqObj.onreadystatechange = function handle;
                  oReqObj.send (null);

                  if (oReqObj.readyState == 4) { // response complete
                     if (oReqObj.status == 200) { // http 200 status is good
                        var reqData = oReqObj.responseText;
                        oSupport.writeToFile (oFileInfo.localPathExpand +"\\"+ oFileInfo.fileName, reqData);
                     }
                  }
               } catch (exp) {
                  // failed
               }
            } else {
               var ftpCmdFileLoc = "%TMP%\\fm_getFile_"+ oFileInfo.fileId +".cmd";

               oSupport.writeToFile (ftpCmdFileLoc, oFileInfo.ftpUser);
               oSupport.writeToFile (ftpCmdFileLoc, oFileInfo.ftpPass, true);
               oSupport.writeToFile (ftpCmdFileLoc, "binary", true);
               oSupport.writeToFile (ftpCmdFileLoc, "get \""+ oFileInfo.ftpPath +"/"+ oFileInfo.ftpFileName +"\" \""+ oFileInfo.localPathExpand +"\\"+ oFileInfo.fileName +"\"", true);
               oSupport.writeToFile (ftpCmdFileLoc, "quit", true);

               var cmdFtp = "FTP -s:"+ ftpCmdFileLoc +" "+ oFileInfo.ftpHost;
               oSupport.getShellObj().Run (cmdFtp, 0, true);
               oSupport.deleteFile (ftpCmdFileLoc);
            }

            try {
               var oFileIn = oSupport.getFsoObj().GetFile (oFileInfo.localPathExpand +"\\"+ oFileInfo.fileName);

               if (oFileIn.Size == 0) oFileInfo.fileStatus = "missing";
               else oFileInfo.fileStatus = "retrieved";
            } catch (exp) {
               oFileInfo.fileStatus = "missing";
            }
         }

         return oFileInfo;
      }


      // #####
      // ## Class::CFtpFileManager::getFileById (fileId)
      // ## return: oFileInfo || null;
      function CFtpFileManager_getFileById (fileId) { // return: oFileInfo || null
         var oSupport = CSupport.getInstance ();

         if (oSupport.isEmpty (fileId)) {
             throw new Error ("Required parameter is empty: fileId.");
         }

         for (var key in this.m_hFileInfoList) {
            var oFileInfo = this.m_hFileInfoList[key];

            if (oFileInfo.fileId == fileId) {
               return this.getFile (oFileInfo.fileName, oFileInfo.ftpHost, oFileInfo.ftpUser, oFileInfo.ftpPass, oFileInfo.ftpPath, oFileInfo.ftpFileName);   
            }
         }

         return null;
      }


      // #####
      // ## Class::CFtpFileManager::putFile (localFileName, ftpHost, ftpUser, ftpPass, ftpPath[, ftpFileName, localPath, bPerformBackUp, bKeepLocal])
      // ## return: oFileInfo;
      function CFtpFileManager_putFile (localFileName, ftpHost, ftpUser, ftpPass, ftpPath, ftpFileName, localPath, bPerformBackUp, bKeepLocal) { // return: oFileInfo
         var oSupport = CSupport.getInstance ();
         var oFileInfo = this.addFile (localFileName, ftpHost, ftpUser, ftpPass, ftpPath, ftpFileName, localPath, bKeepLocal);

         try {
            oFileIn = oSupport.getFsoObj().GetFile (oFileInfo.localPathExpand +"\\"+ oFileInfo.fileName);
         } catch (exp) {
            throw new Error ("CFtpFileManager::putFile\n\nInput file is missing: "+ oFileInfo.localPathExpand +"\\"+ oFileInfo.fileName);
         }

         if (this.m_altTransport.web == oFileInfo.ftpUser) throw new Error ("CFtpFileManager::putFile\n\nNot supported");

         var ftpCmdFileLoc = "%TMP%\\fm_putFile_"+ oFileInfo.fileId +".cmd";

         oSupport.writeToFile (ftpCmdFileLoc, oFileInfo.ftpUser);
         oSupport.writeToFile (ftpCmdFileLoc, oFileInfo.ftpPass, true);
         oSupport.writeToFile (ftpCmdFileLoc, "binary", true);
         
         var aFtpPath = oFileInfo.ftpPath.split("/");
         var tmpPath = "";

         for (var i = 0; i < aFtpPath.length; i++) {
            if (!oSupport.isEmpty(aFtpPath[i])) {
               tmpPath += aFtpPath[i] +"/";

               oSupport.writeToFile (ftpCmdFileLoc, "mkdir "+ tmpPath, true);
            }
         }

         if (bPerformBackUp == true) {
            oSupport.writeToFile (ftpCmdFileLoc, "rename \""+ oFileInfo.ftpPath +"/"+ oFileInfo.ftpFileName +"\" \""+ oFileInfo.ftpPath +"/"+ oFileInfo.ftpFileName +"_"+ oSupport.getMyTimeStamp() +"\"", true);
         }

         oSupport.writeToFile (ftpCmdFileLoc, "put \""+ oFileInfo.localPathExpand +"\\"+ oFileInfo.fileName +"\" \""+ oFileInfo.ftpPath +"/"+ oFileInfo.ftpFileName +"\"", true);
         oSupport.writeToFile (ftpCmdFileLoc, "quit", true);

         var cmdFtp = "FTP -s:"+ ftpCmdFileLoc +" "+ oFileInfo.ftpHost;
         oSupport.getShellObj().Run (cmdFtp, 0, true);

         oSupport.deleteFile (ftpCmdFileLoc);

         oFileInfo.fileStatus = "placed";

         return oFileInfo;
      }


      // #####
      // ## Class::CFtpFileManager::putFileById (fileId, bPerformBackUp)
      // ## return: oFileInfo || null;
      function CFtpFileManager_putFileById (fileId, bPerformBackUp) { // return: oFileInfo || null
         var oSupport = CSupport.getInstance ();

         if (oSupport.isEmpty (fileId)) {
             throw new Error ("Required parameter is empty: fileId.");
         }

         for (var key in this.m_hFileInfoList) {
            var oFileInfo = this.m_hFileInfoList[key];

            if (oFileInfo.fileId == fileId) {
               return this.putFile (oFileInfo.fileName, oFileInfo.ftpHost, oFileInfo.ftpUser, oFileInfo.ftpPass, oFileInfo.ftpPath, oFileInfo.ftpFileName, oFileInfo.localPathExpand, bPerformBackUp);   
            }
         }

         return null;
      }


      // #####
      // ## Class::CFtpFileManager::deleteFile (fileId)
      // ## return: none;
      function CFtpFileManager_deleteFile (fileId) { // return: none
         var oSupport = CSupport.getInstance ();

         for (var key in this.m_hFileInfoList) {
            var oFileInfo = this.m_hFileInfoList[key];

            if (oFileInfo.fileId == fileId && oFileInfo.fileStatus != "deleted") {
               var ftpCmdFileLoc = "%TMP%\\fm_deleteRemoteFile_"+ oFileInfo.fileId +".cmd";

               oSupport.writeToFile (ftpCmdFileLoc, oFileInfo.ftpUser);
               oSupport.writeToFile (ftpCmdFileLoc, oFileInfo.ftpPass, true);
               oSupport.writeToFile (ftpCmdFileLoc, "delete \""+ oFileInfo.ftpPath +"/"+ oFileInfo.ftpFileName +"\"", true);
               oSupport.writeToFile (ftpCmdFileLoc, "quit", true);

               var cmdFtp = "FTP -s:"+ ftpCmdFileLoc +" "+ oFileInfo.ftpHost;
               oSupport.getShellObj().Run (cmdFtp, 0, true);

               oSupport.deleteFile (ftpCmdFileLoc);

               oFileInfo.fileStatus = "deleted";

               if (oFileInfo.fKeepLocal == false) {
                  oSupport.deleteFile (oFileInfo.localPath +"\\"+ oFileInfo.fileName);
               }
            }
         }
      }


      // #####
      // ## Class::CFtpFileManager::deleteAllFiles ()
      // ## return: none;
      function CFtpFileManager_deleteAllFiles () { // return: none
         var oSupport = CSupport.getInstance ();

         for (var key in this.m_hFileInfoList) {
            var oFileInfo = this.m_hFileInfoList[key];

            if (oFileInfo.fileStatus != "deleted" && oFileInfo.fKeepLocal == false) {
               oSupport.deleteFile (oFileInfo.localPath +"\\"+ oFileInfo.fileName);
               
               oFileInfo.fileStatus = "deleted";
            }
         }
      }


      CFtpFileManager.prototype.addFile = CFtpFileManager_addFile;
      CFtpFileManager.prototype.getFile = CFtpFileManager_getFile;
      CFtpFileManager.prototype.getFileById = CFtpFileManager_getFileById;
      CFtpFileManager.prototype.putFile = CFtpFileManager_putFile;
      CFtpFileManager.prototype.putFileById = CFtpFileManager_putFileById;
      CFtpFileManager.prototype.deleteFile = CFtpFileManager_deleteFile;
      CFtpFileManager.prototype.deleteAllFiles = CFtpFileManager_deleteAllFiles;
      // ## /Class::CFtpFileManager()
      // #####


      // #####
      // ## Class::CSupport ()
      // ## return: none - constructor;
      function CSupport () {
         if (CSupport.caller != CSupport.getInstance) {
             throw new Error ("There is no public constructor for CSupport.");
         }

         this.m_oShell = undefined;
         this.m_oFso = undefined;
         this.m_oNet = undefined;
         this.m_newLineChar = "\r\n";

         this.__instance = null;
      }

      //defining static property
      CSupport.__instance = null;


      // #####
      // ## Class::CSupport::getInstance ()
      // ## return: instance of CSupport class;
      CSupport.getInstance = function() {
         if (this.__instance == null) {
            this.__instance = new CSupport();
         }

         return this.__instance;
      }


      // #####
      // ## Class::CSupport::getShellObj ()
      // ## return: WScript.Shell object;
      function CSupport_getShellObj () {
         if (this.m_oShell == undefined) {
            try {
               this.m_oShell = new ActiveXObject ("WScript.Shell");   
            } catch (exp) {
               this.disableAccessAll ();

               throw new Error ("In order for this application to work you need to allow ActiveX control to run.");
            }
         }

         return this.m_oShell;
      }


      // #####
      // ## Class::CSupport::getFsoObj ()
      // ## return: Scripting.FileSystemObject object;
      function CSupport_getFsoObj () {
         if (this.m_oFso == undefined) {
            try {
               this.m_oFso = new ActiveXObject("Scripting.FileSystemObject");
            } catch (exp) {
               this.disableAccessAll ();

               throw new Error ("In order for this application to work you need to allow ActiveX control to run.");
            }
         }

         return this.m_oFso;
      }


      // #####
      // ## Class::CSupport::getNetworkObj ()
      // ## return: WScript.Network object;
      function CSupport_getNetworkObj () {
         if (this.m_oNet == undefined) {
            try {
               this.m_oNet = new ActiveXObject ("WScript.Network");   
            } catch (exp) {
               this.disableAccessAll ();

               throw new Error ("In order for this application to work you need to allow ActiveX control to run.");
            }
         }

         return this.m_oNet;
      }


      // #####
      // ## Class::CSupport::getRequestObj ()
      // ## return: Microsoft.XMLHTTP object;
      function CSupport_getRequestObj () {
         return CSupportBase.getInstance().getRequestObj ();
      }


      // #####
      // ## Class::CSupport::readFile (fileLoc, fDel)
      // ## return: file content or will raise exception;
      function CSupport_readFile (fileLoc, fDel) { // return: file content or will raise exception
         var expandFileLoc = this.getShellObj().ExpandEnvironmentStrings (fileLoc);
         var oReqObj;

         try {
            oReqObj = this.getRequestObj();
            oReqObj.open ("GET", expandFileLoc, false);   
            oReqObj.send (null);

            if (fDel == true) this.deleteFile (fileLoc);
         } catch (exp) {
            throw new Error ("CSupport::readFile\n\n"+ exp.description);
         }

         return oReqObj.responseText;
      }


      // #####
      // ## Class::CSupport::writeToFile (fileLoc, data, [bAppend, bNotAsciiFile])
      // ## return: "" - ok || error message;
      function CSupport_writeToFile (fileLoc, data, bAppend, bNotAsciiFile) { // return: "" - ok || error message
         var ioMode = bAppend == true ? 8 : 2; // ForAppending : ForWriting
         var iFileFormat = bNotAsciiFile == true ? -1 : 0; // Open file as Unicode : ASCII
         var errMsg = "";

         try {
            fileLoc = this.getShellObj().ExpandEnvironmentStrings (fileLoc);

      /*
            // to write non-ASCII characters
            var dataEncoded = "";
            for (var chIndx = 0; chIndx < data.length; chIndx++) {
               var ch = data.charAt(chIndx);
               var chUnicode = data.charCodeAt(chIndx);

               if (chUnicode > 255) ch = encodeURI(ch);
                  dataEncoded += ch;
               }
            }

            data = dataEncoded;
      */

            var oStream = this.getFsoObj().OpenTextFile (fileLoc, ioMode, true, iFileFormat);
            oStream.write (data +"\n");

            oStream.Close();
         } catch (exp) {
            errMsg = "Error occurred while writing to file:";
            errMsg += "\n\nFile: "+ fileLoc;
            errMsg += "\n\nNumber: " + exp.number;
            errMsg += "\nDescription: " + exp.description;
         }

         return errMsg;
      }

            
      // #####
      // ## Class::CSupport::deleteFile (fileLoc)
      // ## return: none;
      function CSupport_deleteFile (fileLoc) { // return: none
         this.getShellObj().Run ("CMD /C DEL /F /Q \""+ fileLoc +"\"", 0, true);
      }


      // #####
      // ## Class::CSupport::disableAccess (sectionName, fAccess)
      // ## return: previous stat of the provided section;
      function CSupport_disableAccess (sectionName, fAccess) { // return: previous stat of the provided section
         var oGuiObj = document.getElementById (sectionName);
         var bPrevStat = true;

         if (this.isEmpty (oGuiObj)) {
            if (sectionName == "CSupport_disableAccessAll") oGuiObj = document;
            else return false;
         }
            
         bPrevStat = oGuiObj.disabled;
         oGuiObj.disabled = fAccess;

         var aGuiObj = oGuiObj.getElementsByTagName ("input");
         for (var i = 0; i < aGuiObj.length; i++) aGuiObj[i].disabled = fAccess;

         aGuiObj = oGuiObj.getElementsByTagName ("div");
         for (var i = 0; i < aGuiObj.length; i++) aGuiObj[i].disabled = fAccess;

         aGuiObj = oGuiObj.getElementsByTagName ("form");
         for (var i = 0; i < aGuiObj.length; i++) aGuiObj[i].disabled = fAccess;
         
         aGuiObj = oGuiObj.getElementsByTagName ("select");
         for (var i = 0; i < aGuiObj.length; i++) aGuiObj[i].disabled = fAccess;

         aGuiObj = oGuiObj.getElementsByTagName ("span");
         for (var i = 0; i < aGuiObj.length; i++) aGuiObj[i].disabled = fAccess;

         aGuiObj = oGuiObj.getElementsByTagName ("acronym");
         for (var i = 0; i < aGuiObj.length; i++) aGuiObj[i].disabled = fAccess;

         aGuiObj = oGuiObj.getElementsByTagName ("b");
         for (var i = 0; i < aGuiObj.length; i++) aGuiObj[i].disabled = fAccess;
         
         aGuiObj = oGuiObj.getElementsByTagName ("font");
         for (var i = 0; i < aGuiObj.length; i++) aGuiObj[i].disabled = fAccess;

         return bPrevStat;
      }


      // #####
      // ## Class::CSupport::disableAccessAll ()
      // ## return: none;
      function CSupport_disableAccessAll () { // return: none
         document.body.scroll = "no";

         this.disableAccess ("CSupport_disableAccessAll", true);
      }


      // #####
      // ## Class::CSupport::getFtpFileList (ftpHost, ftpUser, ftpPass, remotePath)
      // ## return: 0 - ok || 1 - ftp parms || 2 - failed to read file || 3 - remote path doesn't exist;
      // ##
      // !!! HELP !!!
      // ## remotePath could include filename wildcard -- not anymore
      // ## dir /files -- file name only
      // ## dir /files/* -- /files/file1...
      function CSupport_getFtpFileList (ftpHost, ftpUser, ftpPass, remotePath) { // return: 0 - ok || 1 - ftp parms || 2 - failed to read file || 3 - remote path doesn't exist
         var ts = this.getMyTimeStamp ();
         var ftpCmdFileLoc = "%TMP%\\fileStructure_"+ ts +".cmd";
         var ftpOutFileLoc = "%TMP%\\fileStructure_"+ ts +".out";
         var ftpCmdOutFileLoc = "%TMP%\\fileStructure_"+ ts +"_cmd.out";
         var ftpOutFileLocExpand = this.getShellObj().ExpandEnvironmentStrings(ftpOutFileLoc);
         var hStat = {
            errorCode:0,
            errorDesc:"",
            fileList:""
         };

         this.writeToFile (ftpCmdFileLoc, ftpUser);
         this.writeToFile (ftpCmdFileLoc, ftpPass, true);
         this.writeToFile (ftpCmdFileLoc, "cd "+ remotePath, true);
         this.writeToFile (ftpCmdFileLoc, "dir -a "+ ftpOutFileLocExpand, true); // !!! "dir remotePath -a" will not work -- List contents of remotePath will go to local file -a
         this.writeToFile (ftpCmdFileLoc, "quit", true);

         var cmdFtp = "CMD /C FTP -s:"+ ftpCmdFileLoc +" "+ ftpHost +" > "+ ftpCmdOutFileLoc;
         this.getShellObj().Run (cmdFtp, 0, true);

         if (this.getFsoObj().FileExists (ftpOutFileLocExpand) 
            && this.getFsoObj().GetFile (ftpOutFileLocExpand).Size == 0 ) {
            hStat.errorCode = 1;
            hStat.errorDesc = "Check FTP parameters.";
         } else {
            try {
               var fileContent = this.readFile (ftpCmdOutFileLoc, true);

               if (fileContent.match (/250.*CWD.*command.*successful/gi)) {
                  fileContent = this.readFile (ftpOutFileLoc, true);
                  hStat.fileList = fileContent.split (this.m_newLineChar);
               } else {
                  hStat.errorCode = 3;
                  hStat.errorDesc = "Remote path doesn't exist: "+ remotePath;
               }
            } catch (exp) {
               hStat.errorCode = 2;
               hStat.errorDesc = exp.description;
            }
         }

         this.deleteFile (ftpCmdFileLoc);

         return hStat;
      }


      // #####
      // ## Class::CSupport::getFtpFileListParceLine (fileListLine)
      // ## return: file line object;
      function CSupport_getFtpFileListParceLine (fileListLine) { // return: file line object
         var fileType = "unknown";
         var fileName = "";
         var aFileLine = Array ();

         if (!this.isEmpty (fileListLine)) {
            var fileLine = fileListLine.replace (/\s+/g, " ");
            aFileLine = fileLine.split (" ");

            if (aFileLine[8] != "." && aFileLine[8] != "..") {
               if (aFileLine[0].match (/^-/) ) {
                  fileType = "file";
               } else if (aFileLine[0].match (/^[dD]/) ) {
                  fileType = "dir";
               }

               var re = eval ("/(.*)("+ aFileLine[5] +" +"+ aFileLine[6] +" +"+ aFileLine[7] +" )(.*)/");
               fileName = fileListLine.replace (re, "$3");
            }
         }


         return {
            rights:aFileLine[0],
            owner:aFileLine[2],
            size:aFileLine[4],
            changed:aFileLine[5] +" "+ aFileLine[6] +" "+ aFileLine[7],
            //name:aFileLine[8],
            name:fileName,
            type:fileType
         };
      }


      // #####
      // ## Class::CSupport::addEventHandler (oElement, eventName, func)
      // ## return: true || false;
      function CSupport_addEventHandler (oElement, eventName, func) { // return: true || false
         return CSupportBase.getInstance().addEventHandler (oElement, eventName, func);
      }


      // #####
      // ## Class::CSupport::getElemPos ()
      // ## return: actual elem position in a document;
      function CSupport_getElemPos (oElem) { // return: actual elem position in a document
         return CSupportBase.getInstance().getElemPos (oElem);
      }


      // #####
      // ## Class::CSupport::isElemVisible (topLayerDivID);
      // ## return: top layer visibility status;
      function CSupport_isElemVisible (topLayerDivID) { // return: top layer visibility status
         return CSupportBase.getInstance().isElemVisible (topLayerDivID);
      }


      // #####
      // ## Class::CSupport::getXmlNodeValueSafe (oNode [, bDecodeURI])
      // ## return: node value || if node does not exists it will return "";
      function CSupport_getXmlNodeValueSafe (oNode, bDecodeURI) { // return: node value || ""
         return CSupportBase.getInstance().getXmlNodeValueSafe (oNode, bDecodeURI);
      }


      // #####
      // ## Class::CSupport::isEmpty (val)
      // ## return: true || false;
      function CSupport_isEmpty (val) {
         return CSupportBase.getInstance().isEmpty (val);
      }


      // #####
      // ## Class::CSupport::isFirefox ()
      // ## return: true || false;
      function CSupport_isFirefox () {
         return CSupportBase.getInstance().isFirefox();
      }


      // #####
      // ## Class::CSupport::isFullIE ()
      // ## return: true || false;
      function CSupport_isFullIE () {
         return CSupportBase.getInstance().isFullIE();
      }


      // #####
      // ## Class::CSupport::isIE ()
      // ## return: true || false;
      function CSupport_isIE () {
         return CSupportBase.getInstance().isIE();
      }


      // #####
      // ## Class::CSupport::isMobile ()
      // ## return: true || false;
      function CSupport_isMobile () {
         return CSupportBase.getInstance().isMobile();
      }


      // #####
      // ## Class::CSupport::pleaseWaitBox (fShow) // fShow - true || false;
      // ## return: none;
      function CSupport_pleaseWaitBox (fShow) { // return: none
         return CSupportBase.getInstance().pleaseWaitBox (fShow);
      }


      // #####
      // ## Class::CSupport::toggleTopLayer (topLayerDivID, fShow) // fShow - true || false;
      // ## return: none;
      function CSupport_toggleTopLayer (topLayerDivID, fShow) { // return: none
         return CSupportBase.getInstance().toggleTopLayer (topLayerDivID, fShow);
      }


      // #####
      // ## Class::CSupport::expandDiv (divId, expandHBy)
      // ## return: none;
      function CSupport_expandDiv (divId, expandHBy) { // return: none
         return CSupportBase.getInstance().expandDiv (divId, expandHBy);
      }


      // #####
      // ## Class::CSupport::getUserId ()
      // ## return: userId;
      function CSupport_getUserId () {
         return this.getNetworkObj().UserName;
      }


      // #####
      // ## Class::CSupport::getOsVersion ()
      // ## return: winOsVerStr || "";
      function CSupport_getOsVersion () {
         // navigator.appVersion || navigator.platform || navigator.userAgent;
         // var oUserAgent = navigator.userAgent.toLowerCase();
         // var isWin = oUserAgent.indexOf('win') > 0;
         // var isWinnt4 = (isWin && oUserAgent.indexOf('nt 4.0') > 0);

         var oUserAgent = navigator.userAgent;
         var isWin = navigator.userAgent.toLowerCase().indexOf('win') > 0;

         if (!isWin) return "";

         var winVer = oUserAgent.replace(/(.*)(Windows\s+\w+\s*\w*\.*\w*)(;*.*)/i, "$2");
         winVer = winVer.replace (/\s+/g, " ");

         return winVer;
      }

      // #####
      // ## Class::CSupport::getMyLocInfo()
      // ## return: oMyLocInfo;
      function CSupport_getMyLocInfo () { // return: oMyLocInfo
         var loc = location.href.replace (location.protocol, "");
         loc = loc.replace (/^\/*/, "");
         loc = decodeURI (loc);

         var aLocation = loc.split ("/");
         var fullFileName = aLocation [aLocation.length - 1];

         var oMyLocInfo = {
            aLocation: aLocation,
            fullFileName: fullFileName,
            fileName: fullFileName.replace (/\.html*$/, ""),
            path: loc.replace ("/"+ fullFileName, ""),

            protocol: location.protocol,
            location: location.pathname
         };

         return oMyLocInfo;
      }


      // #####
      // ## Class::CSupport::getLocInfo (path)
      // ## return: .path .name .type .fullPath;
      function CSupport_getLocInfo (path) { // return: .path .name .type .fullPath
         path = path.replace (/\\+/g, "\\");

         var path_copy = path;
         var aPath = path.split("\\");
         var aExpandLoc = new Array ();
         var type = "unknown";
         var name = "";

         for (var pElem in aPath) aExpandLoc[pElem] = this.getShellObj().ExpandEnvironmentStrings (aPath[pElem]);

         var expandLoc = aExpandLoc.join ("\\");
         if (this.getFsoObj().FileExists (expandLoc)) {
            aPath.pop();
            path = aPath.join ("\\");

            name = path_copy.replace (path +"\\", "");
            type = "file";
         } else if (this.getFsoObj().FolderExists(expandLoc)) {
            type = "folder";
         }

         return {
            path:path,
            name:name,
            type:type,
            fullPath:expandLoc
         };
      }


      // #####
      // ## Class::CSupport::getMyTimeStamp ()
      // ## return: time stamp;
      function CSupport_getMyTimeStamp () {
         var d = new Date();

         var currMonth = d.getMonth() + 1;
         var currDate = d.getDate();
         var currHour = d.getHours();
         var currMin = d.getMinutes();

         if (currMonth < 10) currMonth = "0"+ currMonth;
         if (currDate < 10) currDate = "0"+ currDate;
         if (currHour < 10) currHour = "0"+ currHour;
         if (currMin < 10) currMin = "0"+ currMin;

         return d.getFullYear() + currMonth + currDate +"_"+ currHour + currMin;
      }


      CSupport.prototype.getShellObj = CSupport_getShellObj;
      CSupport.prototype.getFsoObj = CSupport_getFsoObj;
      CSupport.prototype.getNetworkObj = CSupport_getNetworkObj;
      CSupport.prototype.getRequestObj = CSupport_getRequestObj;
      CSupport.prototype.readFile = CSupport_readFile;
      CSupport.prototype.writeToFile = CSupport_writeToFile;
      CSupport.prototype.deleteFile = CSupport_deleteFile;
      CSupport.prototype.disableAccess = CSupport_disableAccess;
      CSupport.prototype.disableAccessAll = CSupport_disableAccessAll;
      CSupport.prototype.getFtpFileList = CSupport_getFtpFileList;
      CSupport.prototype.getFtpFileListParceLine = CSupport_getFtpFileListParceLine;
      CSupport.prototype.addEventHandler = CSupport_addEventHandler;
      CSupport.prototype.getElemPos = CSupport_getElemPos;
      CSupport.prototype.isElemVisible = CSupport_isElemVisible;
      CSupport.prototype.getXmlNodeValueSafe = CSupport_getXmlNodeValueSafe;
      CSupport.prototype.isEmpty = CSupport_isEmpty;
      CSupport.prototype.isFirefox = CSupport_isFirefox;
      CSupport.prototype.isFullIE = CSupport_isFullIE;
      CSupport.prototype.isIE = CSupport_isIE;
      CSupport.prototype.isMobile = CSupport_isMobile;
      CSupport.prototype.pleaseWaitBox = CSupport_pleaseWaitBox;
      CSupport.prototype.toggleTopLayer = CSupport_toggleTopLayer;
      CSupport.prototype.expandDiv = CSupport_expandDiv;
      CSupport.prototype.getMyTimeStamp = CSupport_getMyTimeStamp;
      CSupport.prototype.getMyLocInfo = CSupport_getMyLocInfo;
      CSupport.prototype.getLocInfo = CSupport_getLocInfo;
      // ## /Class::CSupport
      // #####


      // #####
      // ## Class::CXmlDataFile (xmlFilePath, xmlFileName, dataSetXPath [, bEncodeURI])
      // ## return: none - constructor;
      function CXmlDataFile (xmlFilePath, xmlFileName, dataSetXPath, bEncodeURI) {
         this.m_xmlFilePath = xmlFilePath;
         this.m_xmlFileName = xmlFileName;
         this.m_dataSetXPath = dataSetXPath;

         this.m_xmlFilePathExpand = undefined;
         this.m_xmlFileLoc = undefined;
         this.m_oXmlDomObj = undefined;
         this.m_xmlDataSetsOrigCnt = -1;
         this.m_xmlDataSetsCurrCnt = -1;
         this.m_fXmlChanged = false;
         this.m_colXmlDataSets = undefined;
         this.m_currDataSetIndx = -1; // CXmlDataFile_loadXml doesn't set it to 0 because CXmlGui_nextXmlDataSet using it

         this.m_bEncodeURI = false;
         if (bEncodeURI == true) this.m_bEncodeURI = true;
      }


      // #####
      // ## Class::CXmlDataFile::loadXml () 
      // ## return: oStatus;
      // ## 
      // ## oStatus.errorCode - 0 - ok || 1;
      // ## oStatus.errorDesc;
      // ## oStatus.errorType - none || parser || other;
      // ##
      function CXmlDataFile_loadXml () { // return: oStatus
         var oShell = CSupport.getInstance().getShellObj ();
         
         var oStatus = {
            errorCode: 0,
            errorDesc: "",
            errorType: "none"
         };

         this.m_oXmlDomObj = new ActiveXObject ("Microsoft.XMLDOM");
         this.m_xmlFilePathExpand = oShell.ExpandEnvironmentStrings (this.m_xmlFilePath);
         this.m_xmlFileLoc = this.m_xmlFilePathExpand +"\\"+ this.m_xmlFileName;

         this.m_oXmlDomObj.load(this.m_xmlFileLoc);

         if (this.m_oXmlDomObj.parseError.errorCode) {
            var errMsg = "Error occur while loading XML file:\n\n";
            errMsg += " Line: "+ this.m_oXmlDomObj.parseError.line +"\n"; 
            errMsg += " LinePos: "+ this.m_oXmlDomObj.parseError.linePos +"\n"; 
            errMsg += " SrcText: "+ this.m_oXmlDomObj.parseError.srcText +"\n"; 
            errMsg += " ErrorCode: "+ this.m_oXmlDomObj.parseError.errorCode +"\n";
            errMsg += " ErrorDescription: "+ this.m_oXmlDomObj.parseError.reason +"\n"; 

            oStatus.errorCode = 1;
            oStatus.errorDesc = errMsg;
            oStatus.errorType = "parser";

            this.makeXmlPath (this.m_oXmlDomObj, this.m_dataSetXPath, true);
         } else if (this.m_bEncodeURI == true) {
            var root = this.m_oXmlDomObj.documentElement.firstChild;

            this.decodeXmlValues (root);
         }

         this.m_colXmlDataSets = this.m_oXmlDomObj.selectNodes (this.m_dataSetXPath);
         
         if ( this.m_colXmlDataSets.length == 0) {
            this.makeXmlPath (this.m_oXmlDomObj, this.m_dataSetXPath, true);
            this.m_colXmlDataSets = this.m_oXmlDomObj.selectNodes (this.m_dataSetXPath);
         }

         this.m_xmlDataSetsCurrCnt = this.m_colXmlDataSets.length;

         if (!this.m_oXmlDomObj.parseError.errorCode) this.m_xmlDataSetsOrigCnt = this.m_xmlDataSetsCurrCnt;

         return oStatus;
      }


      // ## Class::CXmlDataFile::isDataChanged ()
      // ## return: true || false;
      function CXmlDataFile_isDataChanged () {
         return this.m_fXmlChanged;
      }


      // ## Class::CXmlDataFile::saveXml (fileLoc)
      // ## return: "" - ok || error msg;
      function CXmlDataFile_saveXml (fileLoc) { // return: "" - ok || error msg
         var oSupport = CSupport.getInstance ();

         if (this.m_bEncodeURI == true) {
            var root = this.m_oXmlDomObj.documentElement.firstChild;
            
            this.encodeXmlValues (root);
         }

         var ret = oSupport.writeToFile (fileLoc, this.m_oXmlDomObj.xml, false, !this.m_bEncodeURI);

         return ret;
      }


      // #####
      // ## Class::CXmlDataFile::encodeXmlValues (oParent)
      // ## return: none;
      function CXmlDataFile_encodeXmlValues (oParent) { // return: none
         var oNodeList = oParent.childNodes;

         for (var nodeIndx = 0; nodeIndx < oNodeList.length; nodeIndx++) {
            var oItem = oNodeList.item (nodeIndx);

            if (oItem.hasChildNodes()) {
               this.encodeXmlValues (oItem);
            } else {
               oItem.text = encodeURI (oItem.text);
            }
         }
      }


      // #####
      // ## Class::CXmlDataFile::decodeXmlValues (oParent)
      // ## return: none;
      function CXmlDataFile_decodeXmlValues (oParent) { // return: none
         if (CSupport.getInstance().isEmpty(oParent)) return;

         var oNodeList = oParent.childNodes;

         for (var nodeIndx = 0; nodeIndx < oNodeList.length; nodeIndx++) {
            var oItem = oNodeList.item (nodeIndx);

            if (oItem.hasChildNodes()) {
               this.decodeXmlValues (oItem);
            } else {
               oItem.text = decodeURI (oItem.text);
            }
         }
      }


      // #####
      // ## Class::CXmlDataFile::makeXmlPath (oCurrNode, path, bCreateNewNode, oNodeToInsertBefore)
      // ## return: newXmlNode;
      function CXmlDataFile_makeXmlPath (oCurrNode, path, bCreateNewNode, oNodeToInsertBefore) { // return: newXmlNode
         var aPath = path.split ("/");
         var childNodeName = aPath.pop();
         var parentPath = aPath.join("/");
         //var parentPath = path.replace(/\/\w+$/, "");
         //var childNodeName = path.replace(/(.*)(\/)(\w+$)/, "$3");
         var oParentNode = oCurrNode.selectSingleNode(parentPath);
         var oChildNode = oCurrNode.selectSingleNode(path);

         if (CSupport.getInstance().isEmpty(oNodeToInsertBefore)) oNodeToInsertBefore = null;

         if (oParentNode == undefined) oParentNode = this.makeXmlPath (oCurrNode, parentPath);
         if (oChildNode == undefined || bCreateNewNode) {
            var oChildNodeNew = this.m_oXmlDomObj.createElement (childNodeName);
            //oParentNode.appendChild (oChildNodeNew);
            oParentNode.insertBefore (oChildNodeNew, oNodeToInsertBefore);

            return oChildNodeNew;
         }
        
         return oChildNode;
      }


      // #####
      // ## Class::CXmlDataFile::getXmlDataSet (dataSetIndx)
      // ## return: xmlDataSet || null - invalid index;
      function CXmlDataFile_getXmlDataSet (dataSetIndx) { // return: xmlDataSet || null - invalid index
         if (dataSetIndx < 0 || dataSetIndx >= this.m_colXmlDataSets.length) return null;

         return this.m_colXmlDataSets[dataSetIndx];
      }


      // #####
      // ## Class::CXmlDataFile::getCurrXmlDataSet ()
      // ## return: current xmlDataSet || null;
      function CXmlDataFile_getCurrXmlDataSet () {
         return this.getXmlDataSet (this.m_currDataSetIndx);
      }


      // #####
      // ## Class::CXmlDataFile::getXmlDataSetSingleNode (dataSetIndx, xmlPath)
      // ## return: xmlNode || 1 - xmlPath is empty;
      function CXmlDataFile_getXmlDataSetSingleNode (dataSetIndx, xmlPath) { // return: xmlNode || 1 - xmlPath is empty
         if (xmlPath == undefined) return 1;

         var oNode = this.m_colXmlDataSets[dataSetIndx].selectSingleNode (xmlPath);
         if (oNode == undefined) oNode = this.makeXmlPath (this.m_colXmlDataSets[dataSetIndx], xmlPath);

         return oNode;
      }


      // #####
      // ## Class::CXmlDataFile::getNodeValueSafe (oNode)
      // ## return: node value || if node does not exists it will return "";
      function CXmlDataFile_getNodeValueSafe (oNode) { // return: node value || ""
         var val = CSupportBase.getInstance().getXmlNodeValueSafe (oNode);

         return val;
      }


      CXmlDataFile.prototype.loadXml = CXmlDataFile_loadXml;
      CXmlDataFile.prototype.isDataChanged = CXmlDataFile_isDataChanged;
      CXmlDataFile.prototype.saveXml = CXmlDataFile_saveXml;
      CXmlDataFile.prototype.encodeXmlValues = CXmlDataFile_encodeXmlValues;
      CXmlDataFile.prototype.decodeXmlValues = CXmlDataFile_decodeXmlValues;
      CXmlDataFile.prototype.getXmlDataSet = CXmlDataFile_getXmlDataSet;
      CXmlDataFile.prototype.getCurrXmlDataSet = CXmlDataFile_getCurrXmlDataSet;
      CXmlDataFile.prototype.getXmlDataSetSingleNode = CXmlDataFile_getXmlDataSetSingleNode;
      CXmlDataFile.prototype.makeXmlPath = CXmlDataFile_makeXmlPath;
      CXmlDataFile.prototype.getNodeValueSafe = CXmlDataFile_getNodeValueSafe;

      // ## /Class::CXmlDataFile
      // #####
   </script>

   <script type="text/javascript" >
      // addEvent(window, "load", sortables_init); // TCPC: ###

      var SORT_COLUMN_INDEX;
      var TIMESTART;

      function sortables_init() {
          // Find all tables with class sortable and make them sortable
          if (!document.getElementsByTagName) return;
          tbls = document.getElementsByTagName("table");
          for (ti=0;ti<tbls.length;ti++) {
              thisTbl = tbls[ti];
              // if (((' '+thisTbl.className+' ').indexOf("sortable") != -1) && (thisTbl.id)) { // TCPC: ###
              if (((' '+thisTbl.className+' ').indexOf("sortable") != -1)) {
                  //initTable(thisTbl.id);
                  ts_makeSortable(thisTbl);
              }
          }
      }

      function ts_makeSortable(table) {
          if (table.rows && table.rows.length > 0) {
              var firstRow = table.rows[0];
          }
          if (!firstRow) return;
          
          // We have a first row: assume it's the header, and make its contents clickable links
          for (var i=0;i<firstRow.cells.length;i++) {
              var cell = firstRow.cells[i];
              var txt = ts_getInnerText(cell);

              if (!cell.className.match(/\bsorttable_nosort\b/)) {  // TCPC: ***
                 cell.innerHTML = '<a href="#" class="sortheader" '+ 
                 'onclick="ts_resortTable(this, '+i+');return false;">' + 
                 txt+'<span class="sortarrow">&nbsp;&nbsp;&nbsp;</span></a>';
              }
          }
      }

      function ts_getInnerText(el) {
         if (typeof el == "string") return el;
         if (typeof el == "undefined") { return el };
         if (el.innerText) return el.innerText;	//Not needed but it is faster
         var str = "";
         
         var cs = el.childNodes;
         var l = cs.length;
         for (var i = 0; i < l; i++) {
            switch (cs[i].nodeType) {
               case 1: //ELEMENT_NODE
                  str += ts_getInnerText(cs[i]);
                  break;
               case 3:	//TEXT_NODE
                  str += cs[i].nodeValue;
                  break;
            }
         }
         return str;
      }

      function ts_resortTable(lnk,clid) {
          TIMERSTART = (new Date()).getTime();
          // get the span
          var span;
          for (var ci=0;ci<lnk.childNodes.length;ci++) {
              if (lnk.childNodes[ci].tagName && lnk.childNodes[ci].tagName.toLowerCase() == 'span') span = lnk.childNodes[ci];
          }
          var spantext = ts_getInnerText(span);
          var td = lnk.parentNode;
          var column = clid || td.cellIndex;
          var table = getParent(td,'TABLE');
          
          // Work out a type for the column
          if (table.rows.length <= 1) return;
          var itm = ts_getInnerText(table.rows[1].cells[column]);
          sortfn = ts_sort_caseinsensitive;
          if (itm.match(/^\d\d[\/-]\d\d[\/-]\d\d\d\d$/)) sortfn = ts_sort_date;
          if (itm.match(/^\d\d[\/-]\d\d[\/-]\d\d$/)) sortfn = ts_sort_date;
          if (itm.match(/^[�$]/)) sortfn = ts_sort_currency;
          if (itm.match(/^[\d\.]+$/)) sortfn = ts_sort_numeric;
          SORT_COLUMN_INDEX = column;
          var firstRow = new Array();
          var newRows = new Array();
          for (i=0;i<table.rows[0].length;i++) { firstRow[i] = table.rows[0][i]; }
          for (j=1;j<table.rows.length;j++) { newRows[j-1] = table.rows[j]; }

          newRows.sort(sortfn);

          if (span.getAttribute("sortdir") == 'down') {
              ARROW = '&nbsp;&nbsp;&uarr;';
              newRows.reverse();
              span.setAttribute('sortdir','up');
          } else {
              ARROW = '&nbsp;&nbsp;&darr;';
              span.setAttribute('sortdir','down');
          }
          
          // We appendChild rows that already exist to the tbody, so it moves them rather than creating new ones
          // don't do sortbottom rows
          for (i=0;i<newRows.length;i++) { if (!newRows[i].className || (newRows[i].className && (newRows[i].className.indexOf('sortbottom') == -1))) table.tBodies[0].appendChild(newRows[i]);}
          // do sortbottom rows only
          for (i=0;i<newRows.length;i++) { if (newRows[i].className && (newRows[i].className.indexOf('sortbottom') != -1)) table.tBodies[0].appendChild(newRows[i]);}
          
          // Delete any other arrows there may be showing
          var allspans = document.getElementsByTagName("span");
          for (var ci=0;ci<allspans.length;ci++) {
              if (allspans[ci].className == 'sortarrow') {
                  if (getParent(allspans[ci],"table") == getParent(lnk,"table")) { // in the same table as us?
                      allspans[ci].innerHTML = '&nbsp;&nbsp;&nbsp;';
                  }
              }
          }
              
          span.innerHTML = ARROW;
          // alert("Time taken: " + ( (new Date()).getTime() - TIMERSTART ) + "ms"); // TCPC: ###
      }

      function getParent(el, pTagName) {
         if (el == null) return null;
         else if (el.nodeType == 1 && el.tagName.toLowerCase() == pTagName.toLowerCase())	// Gecko bug, supposed to be uppercase
            return el;
         else
            return getParent(el.parentNode, pTagName);
      }
      function ts_sort_date(a,b) {
          // y2k notes: two digit years less than 50 are treated as 20XX, greater than 50 are treated as 19XX
          aa = ts_getInnerText(a.cells[SORT_COLUMN_INDEX]);
          bb = ts_getInnerText(b.cells[SORT_COLUMN_INDEX]);
          if (aa.length == 10) {
              dt1 = aa.substr(6,4)+aa.substr(3,2)+aa.substr(0,2);
          } else {
              yr = aa.substr(6,2);
              if (parseInt(yr) < 50) { yr = '20'+yr; } else { yr = '19'+yr; }
              dt1 = yr+aa.substr(3,2)+aa.substr(0,2);
          }
          if (bb.length == 10) {
              dt2 = bb.substr(6,4)+bb.substr(3,2)+bb.substr(0,2);
          } else {
              yr = bb.substr(6,2);
              if (parseInt(yr) < 50) { yr = '20'+yr; } else { yr = '19'+yr; }
              dt2 = yr+bb.substr(3,2)+bb.substr(0,2);
          }
          if (dt1==dt2) return 0;
          if (dt1<dt2) return -1;
          return 1;
      }

      function ts_sort_currency(a,b) { 
          aa = ts_getInnerText(a.cells[SORT_COLUMN_INDEX]).replace(/[^0-9.]/g,'');
          bb = ts_getInnerText(b.cells[SORT_COLUMN_INDEX]).replace(/[^0-9.]/g,'');
          return parseFloat(aa) - parseFloat(bb);
      }

      function ts_sort_numeric(a,b) { 
          aa = parseFloat(ts_getInnerText(a.cells[SORT_COLUMN_INDEX]));
          if (isNaN(aa)) aa = 0;
          bb = parseFloat(ts_getInnerText(b.cells[SORT_COLUMN_INDEX])); 
          if (isNaN(bb)) bb = 0;
          return aa-bb;
      }

      function ts_sort_caseinsensitive(a,b) {
          aa = ts_getInnerText(a.cells[SORT_COLUMN_INDEX]).toLowerCase();
          bb = ts_getInnerText(b.cells[SORT_COLUMN_INDEX]).toLowerCase();
          if (aa==bb) return 0;
          if (aa<bb) return -1;
          return 1;
      }

      function ts_sort_default(a,b) {
          aa = ts_getInnerText(a.cells[SORT_COLUMN_INDEX]);
          bb = ts_getInnerText(b.cells[SORT_COLUMN_INDEX]);
          if (aa==bb) return 0;
          if (aa<bb) return -1;
          return 1;
      }


      function addEvent(elm, evType, fn, useCapture)
      // addEvent and removeEvent
      // cross-browser event handling for IE5+,  NS6 and Mozilla
      // By Scott Andrew
      {
        if (elm.addEventListener){
          elm.addEventListener(evType, fn, useCapture);
          return true;
        } else if (elm.attachEvent){
          var r = elm.attachEvent("on"+evType, fn);
          return r;
        } else {
          alert("Handler could not be removed");
        }
      }
   </script>

   <script>

      // MAIN LOGIC
      var cSpacer2 = "&nbsp;&nbsp;";
      var cSpacer3 = "&nbsp;&nbsp;&nbsp;";
      var cFtpManagerDataSetXPath = "//config";

      var oFtpManagerGui = undefined;
      var buffDivFileListFtpArea = "";

      CSupport.getInstance().addEventHandler (window, "load", uiInit);
      CSupport.getInstance().addEventHandler (window, "unload", onUnloadCheck);


      // #####
      // ## uiInit ()
      // ## return: none;
      function uiInit () {
         var oSupport = CSupport.getInstance();
         oSupport.pleaseWaitBox(false);

         if (!oSupport.isFullIE()) {
            oSupport.disableAccessAll ();
            alert ("Please use IE browser.");

            return;
         }

         var oFileLocInfo = oSupport.getMyLocInfo();

         oFtpManagerGui = new CXmlGui (oFileLocInfo.path, oFileLocInfo.fileName +".xml", cFtpManagerDataSetXPath, "oFtpManagerGui", "");
         var oLoadStatus = oFtpManagerGui.loadXml ();
 
         oFtpManagerGui.nextXmlDataSet (0);
      }


      // #####
      // ## onUnloadCheck ()
      // ## return: none;
      function onUnloadCheck () {
         CFtpFileManager.getInstance().deleteAllFiles ();

         if (!CSupport.getInstance().isEmpty(oFtpManagerGui) && oFtpManagerGui.isDataChanged()) {
            var dlgErrMsg = "Are you sure you want to exit without saving changes?";

            if (confirm (dlgErrMsg)) return 1;

            var ret = oFtpManagerGui.saveXml ();
         }
      }

      
      // #####
      // ## showHideFileListFtpArea ()
      // ## return: none;
      function showHideFileListFtpArea () {
         if (bttnTitleShowHideFileListFtpArea.disabled) return;

         if (CSupport.getInstance().isEmpty (buffDivFileListFtpArea)) {
            buffDivFileListFtpArea = document.getElementById ("divFileListFtpArea").innerHTML;

            document.getElementById ("divFileListFtpArea").innerHTML = "";
            document.getElementById ("bttnTitleShowHideFileListFtpArea").innerHTML = "Show";
         } else {
            document.getElementById ("divFileListFtpArea").innerHTML = buffDivFileListFtpArea;
            document.getElementById ("bttnTitleShowHideFileListFtpArea").innerHTML = "Hide";
            buffDivFileListFtpArea = "";
         }
      }


      // #####
      // ## checkFtpSettings ()
      // ## return: 0 || 1;
      function checkFtpSettings () {
         var oSupport = CSupport.getInstance ();

         var ftpHost = oFtpManagerGui.getGuiObjXmlNode ("inptFtpHost").text;
         var ftpUser = oFtpManagerGui.getGuiObjXmlNode ("inptFtpUser").text;
         var ftpPass = oFtpManagerGui.getGuiObjXmlNode ("inptFtpPass").text;
         var ftpPath = oFtpManagerGui.getGuiObjXmlNode ("inptFtpPath").text;

         if (oSupport.isEmpty (ftpHost) || oSupport.isEmpty (ftpUser) || oSupport.isEmpty (ftpPass)) {
            alert ("Please check ftp settings.");

            return null;
         }

         if (oSupport.isEmpty (ftpPath)) ftpPath = "/";

         return {
            host:ftpHost,
            user:ftpUser,
            pass:ftpPass,
            path:ftpPath
         };
      }


      // #####
      // ## bttnShowFtpFile ()
      // ## return: none;
      function bttnShowFtpFile () {
         showFtpFile ();
      }


      // #####
      // ## showFtpFile ()
      // ## return: 1 - invalid ftp settings || 2 - not able to connect;
      function showFtpFile () {
         var oFtpSettings = checkFtpSettings ();
         if (oFtpSettings == null) return 1;

         var oSupport = CSupport.getInstance ();

         if (!oSupport.isEmpty (buffDivFileListFtpArea)) showHideFileListFtpArea ();

         oSupport.pleaseWaitBox (true);
         disableDownloadBttns (true);

         var hRet = oSupport.getFtpFileList (oFtpSettings.host, oFtpSettings.user, oFtpSettings.pass, oFtpSettings.path); 
         
         if (hRet.errorCode > 0) {
            var dlgErrMsg = "Possibly problem with remote server settings.";              
            dlgErrMsg += "\n\nError description: " + hRet.errorDesc;

            alert (dlgErrMsg);

            oSupport.pleaseWaitBox (false);
            disableDownloadBttns (false);

            return 2;
         }

         var tblFileList = "<table id='tblDownloadFiles' cellpadding='5' cellspacing='0' border='0' class='sortable'>";
         tblFileList += "<thead><tr><th>"+ cSpacer3 +"</th><th>&nbsp;#&nbsp;</th><th class='sorttable_nosort'>&nbsp;Select&nbsp;</th><th>&nbsp;Name&nbsp;</th><th>&nbsp;Type&nbsp;</th><th>&nbsp;Size&nbsp;</th><th>&nbsp;Modified&nbsp;Date&nbsp;</th><th>Owner</th><th>rights</th><th class='sorttable_nosort'></th><th class='sorttable_nosort'></th><th class='sorttable_nosort'></th></tr></thead><tbody>";

         var aFileList = hRet.fileList;
         var fileNum = 0;

         for (var fileLineIndx in aFileList) {
            var oFileLine = oSupport.getFtpFileListParceLine (aFileList[fileLineIndx]);

            if (oFileLine.type != "unknown")
            { 
               var fileName = oFileLine.name.replace (oFtpSettings.path +"/", "");
               var fileTypeStr = (oFileLine.type == "file") ? oFileLine.type : "<b>"+ oFileLine.type +"</b>";
               var cbSelectStr = "";
               var bttnViewStr = "";
               var bttnDownloadStr = "";
               var bttnDeleteStr = "<input type='button' value='Delete' onclick='divFileListFtp_bttnDelete(\""+ fileName +"\");' />";
               fileNum++;

               if (oFileLine.type == "file") {
                  cbSelectStr = "<input type='checkbox' id=\""+ fileName +"\">";
                  bttnViewStr = "<input type='button' value='View' onclick='divFileListFtp_bttnView(\""+ fileName +"\");' />";
                  bttnDownloadStr = "<input type='button' value='Download' onclick='divFileListFtp_bttnDownload(\""+ fileName +"\");' />";
               }

               tblFileList += "<tr><td></td><td>"+ fileNum +"</td><td>"+ cbSelectStr +"</td><td>"+ fileName +"</td><td align='center'>"+ fileTypeStr +"</td><td>"+ oFileLine.size +"</td><td align='center'>"+ oFileLine.changed +"</td><td>"+ oFileLine.owner +"</td><td>"+ oFileLine.rights +"</td><td>"+ bttnViewStr +"</td><td>"+ bttnDeleteStr +"</td><td>"+ bttnDownloadStr +"</td></tr>";
            }
         }

         tblFileList += "</tbody></table>";

         divFileListFtp.innerHTML = tblFileList;

         sortables_init ();

         oSupport.pleaseWaitBox (false);
         disableDownloadBttns (false);
      }


      // #####
      // ## divFileListFtp_bttnView (fileName)
      // ## return: 0 || 1;
      function divFileListFtp_bttnView (fileName) {
         var oSupport = CSupport.getInstance();

         oSupport.pleaseWaitBox (true);

         var oFileInfo = downloadFile (fileName);
         var fileTmpLoc = "\""+ oFileInfo.localPathExpand +"\\"+ oFileInfo.fileName +"\"";

         try {
            oSupport.getShellObj().Run (fileTmpLoc, 1, false);
         } catch (exp) {
           alert("Can't open file: "+ fileName +"\n\n"+ exp.description);
         }

         oSupport.pleaseWaitBox (false);

         return 0;
      }


      // #####
      // ## divFileListFtp_bttnDelete (fileName)
      // ## return: 0 || 1;
      function divFileListFtp_bttnDelete (fileName) {
         var dlgErrMsg = "Are you sure you want to delete: "+ fileName +"?";

         if (!confirm (dlgErrMsg)) return;

         var oFtpSettings = checkFtpSettings ();
         if (oFtpSettings == null) return 1;

         var oSupport = CSupport.getInstance ();

         oSupport.pleaseWaitBox (true);

         var fm = CFtpFileManager.getInstance();
         var oFileInfo = fm.addFile (fileName, oFtpSettings.host, oFtpSettings.user, oFtpSettings.pass, oFtpSettings.path, fileName, "", true);

         fm.deleteFile (oFileInfo.fileId);

         showFtpFile ();

         oSupport.pleaseWaitBox (false);

         return 0;
      }


      // #####
      // ## divFileListFtp_bttnDownload (fileName)
      // ## return: 0 || 1;
      function divFileListFtp_bttnDownload (fileName) {
         var oSupport = CSupport.getInstance();
         var localWorkingPath = getLocalWorkingPath();

         if (!oSupport.getFsoObj().FolderExists (localWorkingPath)) {
            alert ("Download path doesn't exist.");
            return 1;
         }

         oSupport.pleaseWaitBox (true);

         getFileToPermLoc (fileName, localWorkingPath);

         oSupport.pleaseWaitBox (false);

         bttnShowLocalFiles ();

         alert ("Download completed.");

         return 0;
      }


      // #####
      // ## downloadFile (fileName)
      // ## return: oFileInfo;
      function downloadFile (fileName) {
         var oFtpSettings = checkFtpSettings ();
         if (oFtpSettings == null) return 1;

         var oFtpFileManager = CFtpFileManager.getInstance();
         var oFileInfo = oFtpFileManager.getFile (fileName, oFtpSettings.host, oFtpSettings.user, oFtpSettings.pass, oFtpSettings.path, fileName);
         
         return oFileInfo;
      }

      
      // #####
      // ## getFileToPermLoc (fileName, localPermPath)
      // ## return: none;
      function getFileToPermLoc (fileName, localPermPath) {
         var oSupport = CSupport.getInstance();
         var oFileInfo = downloadFile (fileName);
         var fileTmpLoc = oFileInfo.localPathExpand +"\\"+ oFileInfo.fileName;
         var fileDownloadLoc = localPermPath +"\\"+ oFileInfo.fileName;

         try {
            oSupport.getFsoObj().CopyFile (fileTmpLoc, fileDownloadLoc);
         } catch (exp) {
           alert("Can't copy file: "+ fileName +"\n\n"+ exp.description);
         }
      }


      // #####
      // ## bttnDownloadSelected (bDownloadAll)
      // ## return: none;
      function bttnDownloadSelected (bDownloadAll) {
         var oSupport = CSupport.getInstance();
         var distPath = getLocalWorkingPath ();

         if (!oSupport.getFsoObj().FolderExists (distPath)) {
            alert ("Upload path doesn't exist.");
            return 1;
         }

         oSupport.pleaseWaitBox (true);
         disableDownloadBttns(true);

         var oTab = document.getElementById("tblDownloadFiles");
         var colRows = oTab.rows;
         var colmnCnt = colRows[0].cells.length;
         var bUserSelected = false;

         for (var rowIndx = 0; rowIndx < colRows.length; rowIndx++) {
            var oRow = colRows[rowIndx];
            var cntCells = oRow.cells.length;

            if (oRow.firstChild.tagName != "TH") {
               var oSelCell = oRow.cells[2];

               if (!oSupport.isEmpty (oSelCell.firstChild)) {
                  if (oSelCell.firstChild.checked == true || bDownloadAll == true) {
                     getFileToPermLoc (oSelCell.firstChild.id, distPath);

                     bUserSelected = true;
                  }
               }
            }
         }

         if (bUserSelected) {
            bttnShowLocalFiles ();

            alert ("Download completed.");
         } else alert ("No items selected for download.");

         oSupport.pleaseWaitBox (false);
         disableDownloadBttns(false);
      }


      // #####
      // ## bttnDownloadAll ()
      // ## return: none;
      function bttnDownloadAll () {
         var dlgErrMsg = "Are you sure you want to Download all files?";

         if (!confirm (dlgErrMsg)) return;

         bttnDownloadSelected (true);
      }


      // #####
      // ## getLocalWorkingPath ()
      function getLocalWorkingPath () {
         var oSupport = CSupport.getInstance();
         var localWorkingPath = oFtpManagerGui.getGuiObjXmlNode ("inptLocalWorkingPath").text;

         return localWorkingPath = oSupport.getShellObj().ExpandEnvironmentStrings (localWorkingPath);
      }


      // #####
      // ## bttnShowLocalFiles ()
      // ## return: none;
      function bttnShowLocalFiles () {
         var oSupport = CSupport.getInstance();
         var localWorkingPath = getLocalWorkingPath();

         if (!oSupport.getFsoObj().FolderExists (localWorkingPath)) {
            alert ("Local path doesn't exist.");
            return 1;
         }

         oSupport.pleaseWaitBox (true);
         disableUploadBttns(true);

         var tblFileList = "<table id='tblUploadFiles' cellpadding='5' cellspacing='0' border='0' class='sortable'>";
         tblFileList += "<thead><tr><th>"+ cSpacer3 +"</th><th>&nbsp;#&nbsp;</th><th class='sorttable_nosort'>&nbsp;Select&nbsp;</th><th>&nbsp;Name&nbsp;</th><th>&nbsp;Size&nbsp;</th><th>&nbsp;Modified&nbsp;Date&nbsp;</th><th>&nbsp;File&nbsp;Type&nbsp;</th><th class='sorttable_nosort'></th><th class='sorttable_nosort'></th><th class='sorttable_nosort'></th></tr></thead><tbody>";

         var oFolder = oSupport.getFsoObj().GetFolder(localWorkingPath);
         var enumFiles = new Enumerator (oFolder.Files);
         var fileNum = 0;
         
         for (; !enumFiles.atEnd(); enumFiles.moveNext()) {
            var oFileItem = enumFiles.item();
            fileNum++;

            var cbSelectStr = "<input type='checkbox' id=\""+ oFileItem.Name +"\">";
            var bttnViewLocalStr = "<input type='button' value='View' onclick='divFileListLocal_bttnView(\""+ oFileItem.Name +"\");' />";
            var bttnDeleteLocalStr = "<input type='button' value='Delete' onclick='divFileListLocal_bttnDelete(\""+ oFileItem.Name +"\");' />";
            var bttnUploadStr = "<input type='button' value='Upload' onclick='divFileListLocal_bttnUpload(\""+ oFileItem.Name +"\");' />";

            tblFileList += "<tr><td></td><td>"+ fileNum +"</td><td>"+ cbSelectStr +"</td><td>"+ oFileItem.Name +"</td><td>"+ oFileItem.Size +"</td><td align='center'>"+ oFileItem.DateLastModified +"</td><td align='center'>"+ oFileItem.Type +"</td><td>"+ bttnViewLocalStr +"</td><td>"+ bttnDeleteLocalStr +"</td><td>"+ bttnUploadStr +"</td></tr>";
         }

         tblFileList += "</tbody></table>";

         divFileListLocal.innerHTML = tblFileList;

         sortables_init ();

         oSupport.pleaseWaitBox (false);
         disableUploadBttns (false);
      }


      // #####
      // ## divFileListLocal_bttnView (fileName)
      // ## return: 0 || 1;
      function divFileListLocal_bttnView (fileName) {
         var oSupport = CSupport.getInstance();

         oSupport.pleaseWaitBox (true);

         var localWorkingPath = getLocalWorkingPath();
         var fileLoc = "\""+ localWorkingPath +"\\"+ fileName +"\"";

         try {
            oSupport.getShellObj().Run (fileLoc, 1, false);
         } catch (exp) {
           alert("Can't open file.\n\n"+ exp.description);
         }

         oSupport.pleaseWaitBox (false);

         return 0;
      }


      // #####
      // ## divFileListLocal_bttnDelete (fileName)
      // ## return: none;
      function divFileListLocal_bttnDelete (fileName) {
         var dlgErrMsg = "Are you sure you want to delete: "+ fileName +"?";

         if (!confirm (dlgErrMsg)) return;

         var oSupport = CSupport.getInstance ();
         var localWorkingPath = getLocalWorkingPath();
         var fileLoc = localWorkingPath +"\\"+ fileName;

         oSupport.pleaseWaitBox (true);

         oSupport.deleteFile (fileLoc);

         oSupport.pleaseWaitBox (false);

         bttnShowLocalFiles();
      }


      // #####
      // ## divFileListLocal_bttnUpload (fileName)
      // ## return: none;
      function divFileListLocal_bttnUpload (fileName) {
         var oFtpSettings = checkFtpSettings ();
         if (oFtpSettings == null) return 1;

         var oSupport = CSupport.getInstance();

         oSupport.pleaseWaitBox (true);

         var localWorkingPath = getLocalWorkingPath();
         var oFtpFileManager = CFtpFileManager.getInstance();
         oFtpFileManager.putFile (fileName, oFtpSettings.host, oFtpSettings.user, oFtpSettings.pass, oFtpSettings.path, fileName, localWorkingPath, false, true);

         oSupport.pleaseWaitBox (false);

         showFtpFile ();
      }


      // #####
      // ## bttnUploadFile ()
      // ## return: none;
      function bttnUploadFile () {
         var oSupport = CSupport.getInstance();
         var fileLoc = document.getElementById("inptUploadFileLoc").value; // should call before pleaseWaitBox

         oSupport.pleaseWaitBox (true);
         disableUploadBttns(true);

         var oFileInfo = oSupport.getLocInfo (fileLoc);
         uploadFile (oFileInfo.name, oFileInfo.path);

         oSupport.pleaseWaitBox (false);
         disableUploadBttns(false);

         showFtpFile ();

         alert ("Upload completed.");
      }


      // #####
      // ## uploadFile (fileName, path)
      // ## return: none;
      function uploadFile (fileName, path) {
         var oFtpSettings = checkFtpSettings ();
         if (oFtpSettings == null) return 1;

         var oFtpFileManager = CFtpFileManager.getInstance();
         oFtpFileManager.putFile (fileName, oFtpSettings.host, oFtpSettings.user, oFtpSettings.pass, oFtpSettings.path, fileName, path, false, true);
      }


      // #####
      // ## bttnUploadSelected (bUploadAll)
      // ## return: none;
      function bttnUploadSelected (bUploadAll) {
         var oSupport = CSupport.getInstance();
         var srcPath = getLocalWorkingPath ();

         if (!oSupport.getFsoObj().FolderExists (srcPath)) {
            alert ("Upload path doesn't exist.");
            return 1;
         }

         oSupport.pleaseWaitBox (true);
         disableUploadBttns(true);

         var oTab = document.getElementById("tblUploadFiles");
         var colRows = oTab.rows;
         var colmnCnt = colRows[0].cells.length;
         var bUserSelected = false;

         for (var rowIndx = 0; rowIndx < colRows.length; rowIndx++) {
            var oRow = colRows[rowIndx];
            var cntCells = oRow.cells.length;

            if (oRow.firstChild.tagName != "TH") {
               var oSelCell = oRow.cells[2];

               if (oSelCell.firstChild.checked == true || bUploadAll == true) {
                  uploadFile (oSelCell.firstChild.id, srcPath);

                  bUserSelected = true;
               }
            }
         }

         if (bUserSelected) {
            showFtpFile ();

            alert ("Upload completed.");
         } else alert ("No items selected for upload.");

         oSupport.pleaseWaitBox (false);
         disableUploadBttns(false);
      }


      // #####
      // ## bttnUploadAll ()
      // ## return: none;
      function bttnUploadAll () {
         var dlgErrMsg = "Are you sure you want to Upload all files?";

         if (!confirm (dlgErrMsg)) return;

         bttnUploadSelected (true);
      }


      function disableUploadBttns (bDisable) {
         document.getElementById("bttnShowLocalFiles").disabled = bDisable;
         document.getElementById("bttnUploadFile").disabled = bDisable;
         document.getElementById("bttnUploadSelected").disabled = bDisable;
         document.getElementById("bttnUploadAll").disabled = bDisable;
      }

      function disableDownloadBttns (bDisable) {
         document.getElementById("bttnShowFtpFile").disabled = bDisable;
         document.getElementById("bttnTitleShowHideFileListFtpArea").disabled = bDisable;
         document.getElementById("bttnDownloadSelected").disabled = bDisable;
         document.getElementById("bttnDownloadAll").disabled = bDisable;
      }

/*<!-- TWO STEPS TO INSTALL FTP SERVER LOGIN:

  1.  Copy the coding into the HEAD of your HTML document
  2.  Add the last code into the BODY of your HTML document  -->

<!-- STEP ONE: Paste this code into the HEAD of your HTML document  -->

<HEAD>

<SCRIPT LANGUAGE="JavaScript">
<!-- Original:  Reinout Verkerk -->
<!-- This script and many more are available free online at -->
<!-- The JavaScript Source!! http://javascript.internet.com -->

<!-- Begin
function Login(form) {
// NOTE: the ftp:// part is automatically added by the script, you do not need it below.

var server = "server-ftp-address.com";

// Do not edit below this point
var username = form.username.value;
var password = form.password.value;

if (username && password && server) {
var ftpsite = "ftp://" + username + ":" + password + "@" + server;
window.location = ftpsite;
}
else {
alert("Please enter your username, password, and FTP server's address.");
   }
}
//  End -->
</script>
</HEAD>

<!-- STEP TWO: Copy this code into the BODY of your HTML document  -->

<BODY>

<center>
<form name=login>
<input type=hidden name=server value="ftp://yoursite.com" size=14>
<table width=250 border=0 cellpadding=3>
<tr>
<td colspan=2 align=center><b><h2>Logon to FTP Server!</h2></b></td>
</tr>
<tr>
<td>Username:</td>
<td><input type=text name=username size=20></td>
</tr>
<tr>
<td>Password:</td>
<td><input type=password name=password size=20></td>
</tr>
<tr>
<td colspan=2 align=center>
<input type=button value="Login!" onClick="Login(this.form)"></td>
</tr>
</table>
</form>
</center>

<!-- Terms say you have to leave ads in so.. -->
<p><center>
<font face="arial, helvetica" size="-2">Free JavaScripts provided<br>
by <a href="http://javascriptsource.com">The JavaScript Source</a></font>
</center><p>

<!-- Script Size:  1.53 KB -->*/
