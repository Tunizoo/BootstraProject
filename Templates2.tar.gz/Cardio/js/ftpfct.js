var JSFtp = require('jsftp');

module.exports= 
function ftpUpload(fpath) {
	var Ftp = new JSFtp({
	  host: "ftp.byethost12.com",
	  port: 21,
	  user: "b12_18839787",
	  pass: "bismillah_123",
	  debugMode: true
	});

	Ftp.put(fpath, "work-demo.byethost12.com/htdocs/demo", function(hadError) {
	  if (!hadError)
	    console.log("File transferred successfully!");
	});
}
