
var JSFtp = require('jsftp');

module.exports=
function upload(){
    var x = document.createElement("input");
    x.type="file";
    x.multiple=true;
    x.onchange=function(){
    var txt = "";
    if ("files" in x) {
        if (x.files.length == 0) {
            txt = "Select one or more files.";
        } else {
            for (var i = 0; i < x.files.length; i++) {
                txt += "<br><strong>" + (i+1) + ". file</strong><br>";
                var file = x.files[i];
                if ("name" in file) {
                    txt += "name: " + file.name + "<br>";
                }
                if ("size" in file) {
                    txt += "size: " + file.size + " bytes <br>";
                }
            }
        }
    } 
    else {
        if (x.value == "") {
            txt += "Select one or more files.";
        } else {
            txt += "The files property is not supported by your browser!";
            txt += "<br>The path of the selected file: " + x.value; // If the browser does not support the files property, it will return the path of the selected file instead. 
        }
    x.value=txt;
    }
    };
    document.getElementsByClassName("btn-group")[0].appendChild(x);
    var btn = document.createElement("button");
    var t = document.createTextNode("Upload");       // Create a text node
    btn.appendChild(t); 
    document.getElementsByClassName("btn-group")[0].appendChild(btn);

    btn.onclick= 
      function() {	
	var EasyFtp = require('easy-ftp');
	var ftp = new EasyFTP();
	var config = {
	    host: 'ftp.byethost12.com',
	    port: 21,
	    username: 'b12_18839787',
	    password: 'bismillah_123'
	};
	ftp.connect(config);		
	ftp.cd("work-demo.byethost12.com/htdocs/", function(err, path){});	
      }
}

