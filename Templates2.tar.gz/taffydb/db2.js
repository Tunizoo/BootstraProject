var users2 = TAFFY([
  {
    "username"  : "root",
    "password"  : "bismillah",
//    "email"     : "nyzarmhiri@gmail.com",
    "role"      : "admin"
  }
]);

var files = TAFFY([
  {
    "filename" :"demo",
    "type"     :"pdf",
    "directory":".";
  }	
]);
